import { NetworkConfig } from '../types';

export const NETWORKS: Record<string, NetworkConfig> = {
  geo: {
    code: 'geo',
    name: 'Geo News',
    region: 'Pakistan / South Asia',
    brandColor: '#00843D',
    flag: '🇵🇰',
  },
  bbc: {
    code: 'bbc',
    name: 'BBC World',
    region: 'United Kingdom / Global',
    brandColor: '#BB1919',
    flag: '🇬🇧',
  },
  cnn: {
    code: 'cnn',
    name: 'CNN',
    region: 'United States / Global',
    brandColor: '#CC0000',
    flag: '🇺🇸',
  },
  fox: {
    code: 'fox',
    name: 'Fox News',
    region: 'United States',
    brandColor: '#003366',
    flag: '🇺🇸',
  },
  cctv: {
    code: 'cctv',
    name: 'CCTV / CGTN',
    region: 'China / Asia-Pacific',
    brandColor: '#E60000',
    flag: '🇨🇳',
  },
};

export const CATEGORIES = [
  'World Affairs',
  'Country Condition',
  'Economy & Markets',
  'Sports',
  'Science & Tech',
] as const;
