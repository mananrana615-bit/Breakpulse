/**
 * Robust YouTube Embed URL parser & formatter
 * Handles standard watch URLs, youtu.be short links, live stream URLs, channel IDs,
 * and direct embed URLs. Ensures YouTube allows playback inside the applet iframe.
 */

export function parseYouTubeVideoId(input: string): string | null {
  if (!input) return null;
  const str = input.trim();

  // 1. Direct 11-char video ID (e.g., sUKwTVAc0Dg)
  if (/^[a-zA-Z0-9_-]{11}$/.test(str)) {
    return str;
  }

  // 2. youtu.be/VIDEO_ID
  const youtuBeMatch = str.match(/youtu\.be\/([a-zA-Z0-9_-]{11})/i);
  if (youtuBeMatch && youtuBeMatch[1]) return youtuBeMatch[1];

  // 3. youtube.com/watch?v=VIDEO_ID
  const watchMatch = str.match(/[?&]v=([a-zA-Z0-9_-]{11})/i);
  if (watchMatch && watchMatch[1]) return watchMatch[1];

  // 4. youtube.com/live/VIDEO_ID
  const liveMatch = str.match(/youtube\.com\/live\/([a-zA-Z0-9_-]{11})/i);
  if (liveMatch && liveMatch[1]) return liveMatch[1];

  // 5. youtube.com/embed/VIDEO_ID
  const embedMatch = str.match(/youtube(?:-nocookie)?\.com\/embed\/([a-zA-Z0-9_-]{11})/i);
  if (embedMatch && embedMatch[1]) return embedMatch[1];

  return null;
}

export function formatYouTubeEmbedUrl(input: string): string {
  if (!input) {
    // Default to verified Geo News official stream
    return 'https://www.youtube-nocookie.com/embed/sUKwTVAc0Dg?autoplay=1&mute=1&playsinline=1&rel=0';
  }

  const videoId = parseYouTubeVideoId(input);
  if (videoId) {
    return `https://www.youtube-nocookie.com/embed/${videoId}?autoplay=1&mute=1&playsinline=1&rel=0`;
  }

  // If already an embed link (e.g. custom stream or channel live_stream), make sure parameters are safe
  if (input.includes('/embed/')) {
    if (!input.includes('autoplay=')) {
      const glue = input.includes('?') ? '&' : '?';
      return `${input}${glue}autoplay=1&mute=1&playsinline=1&rel=0`;
    }
    return input;
  }

  // Fallback
  return input;
}

export const OFFICIAL_STREAM_PRESETS = [
  {
    id: 'geo-news',
    name: '🇵🇰 Geo News Live',
    channel: 'Geo News Official',
    videoId: 'sUKwTVAc0Dg',
    url: 'https://www.youtube-nocookie.com/embed/sUKwTVAc0Dg?autoplay=1&mute=1&playsinline=1&rel=0',
    externalUrl: 'https://www.youtube.com/watch?v=sUKwTVAc0Dg',
  },
  {
    id: 'bbc-world',
    name: '🇬🇧 BBC News Live',
    channel: 'BBC News',
    videoId: '16niRr50-MSBwiO3YDb3RA',
    url: 'https://www.youtube-nocookie.com/embed/16niRr50-MSBwiO3YDb3RA?autoplay=1&mute=1&playsinline=1&rel=0',
    externalUrl: 'https://www.youtube.com/@BBCNews/live',
  },
  {
    id: 'al-jazeera',
    name: '🌍 Al Jazeera Live',
    channel: 'Al Jazeera English',
    videoId: 'bNyUyrR0PHo',
    url: 'https://www.youtube-nocookie.com/embed/bNyUyrR0PHo?autoplay=1&mute=1&playsinline=1&rel=0',
    externalUrl: 'https://www.youtube.com/watch?v=bNyUyrR0PHo',
  },
  {
    id: 'cgtn',
    name: '🇨🇳 CGTN Live',
    channel: 'CGTN / CCTV',
    videoId: 'grNz-aDmcr2uuto8_DL2jg',
    url: 'https://www.youtube-nocookie.com/embed/grNz-aDmcr2uuto8_DL2jg?autoplay=1&mute=1&playsinline=1&rel=0',
    externalUrl: 'https://www.youtube.com/@cgtn/live',
  },
];
