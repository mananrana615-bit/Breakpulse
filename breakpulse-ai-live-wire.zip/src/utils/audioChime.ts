// Web Audio API broadcast sound synthesizer with sweet, gentle acoustic tones
class BroadcastSoundEngine {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;
  private volumeMultiplier: number = 0.5; // low, sweet volume

  constructor() {}

  private initContext() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  public setVolume(vol: number) {
    this.volumeMultiplier = Math.max(0.1, Math.min(1.0, vol));
  }

  // Sweet, soft, mellow acoustic droplet chime (low amplitude, gentle decay)
  public playTickerPulse() {
    if (this.isMuted) return;
    try {
      this.initContext();
      if (!this.ctx) return;
      if (this.ctx.state === 'suspended') {
        this.ctx.resume();
      }

      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();

      // Soft sine tone around F#5 / 740 Hz, warm and acoustic
      osc.type = 'sine';
      osc.frequency.setValueAtTime(698.46, now); // F5
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.09); // gentle rise to A5

      // Low pass to remove any harsh clicks
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(2200, now);

      // Very low amplitude (sweet & soft as requested)
      const baseGain = 0.018 * this.volumeMultiplier;
      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.exponentialRampToValueAtTime(baseGain, now + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.12);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + 0.12);
    } catch {
      // Ignore audio restrictions
    }
  }

  // Sweet gentle 2-note bell for breaking notifications
  public playBreakingChime() {
    if (this.isMuted) return;
    try {
      this.initContext();
      if (!this.ctx) return;
      if (this.ctx.state === 'suspended') {
        this.ctx.resume();
      }

      const now = this.ctx.currentTime;
      [587.33, 880.0].forEach((freq, idx) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + idx * 0.08);

        const baseGain = 0.02 * this.volumeMultiplier;
        gain.gain.setValueAtTime(0.0001, now + idx * 0.08);
        gain.gain.exponentialRampToValueAtTime(baseGain, now + idx * 0.08 + 0.01);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.08 + 0.3);

        osc.connect(gain);
        gain.connect(this.ctx!.destination);

        osc.start(now + idx * 0.08);
        osc.stop(now + idx * 0.08 + 0.3);
      });
    } catch {
      // Ignore
    }
  }
}

export const soundEngine = new BroadcastSoundEngine();
