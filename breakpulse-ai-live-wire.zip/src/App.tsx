import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  RefreshCw,
  Bookmark,
  Sparkles,
  ArrowRight,
  Clock,
  MapPin,
  TrendingUp,
  Flame,
  Globe2
} from 'lucide-react';
import { NewsItem, SourceCode, MainNavTab, AdminSettingsState } from './types';
import { NETWORKS } from './utils/constants';
import { soundEngine } from './utils/audioChime';
import { BreakingTicker } from './components/BreakingTicker';
import { EditorialHeader } from './components/EditorialHeader';
import { BroadsheetHome } from './components/BroadsheetHome';
import { AllHeadlinesTab } from './components/AllHeadlinesTab';
import { AISummaryModal } from './components/AISummaryModal';
import { AIDetailModal } from './components/AIDetailModal';
import { SettingsAdminModal } from './components/SettingsAdminModal';

export default function App() {
  const [feedItems, setFeedItems] = useState<NewsItem[]>([]);
  const [activePulseIndex, setActivePulseIndex] = useState<number>(0);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [pulseIntervalSec, setPulseIntervalSec] = useState<number>(5);
  const [isMuted, setIsMuted] = useState<boolean>(false); // Enabled with sweet, soft volume
  const [preferUrdu, setPreferUrdu] = useState<boolean>(false);
  const [selectedSource, setSelectedSource] = useState<SourceCode>('all');
  const [activeNavTab, setActiveNavTab] = useState<MainNavTab>('home');
  const [selectedItemForDetail, setSelectedItemForDetail] = useState<NewsItem | null>(null);
  const [selectedItemForSummary, setSelectedItemForSummary] = useState<NewsItem | null>(null);
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>([]);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [lastSyncTime, setLastSyncTime] = useState<string>('Just now');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isJustUpdated, setIsJustUpdated] = useState<boolean>(false);
  const [freshNewsToast, setFreshNewsToast] = useState<string | null>(null);

  // Custom stories published by BreakPulse Admin CMS
  const [customStories, setCustomStories] = useState<NewsItem[]>([]);

  // Admin configuration (passcode, live stream, custom ticker alert)
  const [adminSettings, setAdminSettings] = useState<AdminSettingsState>({
    adminPasscode: 'admin123',
    tickerAlert: '',
    liveStreamUrl: 'https://www.youtube.com/embed/live_stream?channel=UCcwmb_d_M_hD0J2J_vJz_hA',
    selectedPresetStream: 'Geo News Live',
    isStreamActive: false,
  });

  // Load preferences from localStorage
  useEffect(() => {
    try {
      const savedBookmarks = localStorage.getItem('breakpulse_bookmarks');
      if (savedBookmarks) setBookmarkedIds(JSON.parse(savedBookmarks));

      const savedUrdu = localStorage.getItem('breakpulse_prefer_urdu');
      if (savedUrdu) setPreferUrdu(savedUrdu === 'true');

      const savedMute = localStorage.getItem('breakpulse_muted');
      if (savedMute) {
        const muted = savedMute === 'true';
        setIsMuted(muted);
        soundEngine.setMuted(muted);
      }

      const savedAdmin = localStorage.getItem('breakpulse_admin_config');
      if (savedAdmin) {
        setAdminSettings(JSON.parse(savedAdmin));
      }

      const savedCustom = localStorage.getItem('breakpulse_custom_stories');
      if (savedCustom) {
        const parsed: NewsItem[] = JSON.parse(savedCustom);
        const now = Date.now();
        const active = parsed.filter(
          (s) => !s.pinExpiryTimestamp || s.pinExpiryTimestamp > now
        );
        setCustomStories(active);
      }
    } catch (e) {
      console.warn('LocalStorage load error:', e);
    }
  }, []);

  // Fetch shared portal state & live wire feed from central server
  const fetchFeed = async (forceRefresh: boolean = false) => {
    setIsRefreshing(true);
    try {
      const url = forceRefresh ? '/api/news/feed?refresh=true' : '/api/portal/state';
      const res = await fetch(url);
      const data = await res.json();

      if (data) {
        if (data.adminSettings) {
          setAdminSettings(data.adminSettings);
        }
        if (Array.isArray(data.customStories)) {
          setCustomStories(data.customStories);
        }

        const itemsList = Array.isArray(data.items) ? data.items : Array.isArray(data.feed) ? data.feed : [];
        if (itemsList.length > 0) {
          let readMap: Record<string, boolean> = {};
          try {
            const storedArchive = localStorage.getItem('breakpulse_all_headlines');
            if (storedArchive) {
              const parsed = JSON.parse(storedArchive);
              if (Array.isArray(parsed)) {
                parsed.forEach((item: NewsItem) => {
                  if (item.read) readMap[item.id] = true;
                });
              }
            }
          } catch {}

          const merged: NewsItem[] = itemsList.map((item: NewsItem) => ({
            ...item,
            read: Boolean(readMap[item.id] || item.read),
          }));

          setFeedItems(merged);
          setLastSyncTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));

          try {
            localStorage.setItem('breakpulse_all_headlines', JSON.stringify(merged));
          } catch {}
        }
      }
    } catch (err) {
      console.error('Failed to fetch wire feed:', err);
    } finally {
      setIsRefreshing(false);
    }
  };

  // Poll for genuine brand-new internet breaking news from Geo News / Google News RSS
  const pollFreshInternetNews = async () => {
    try {
      const res = await fetch('/api/news/fresh');
      const data = await res.json();
      if (data && Array.isArray(data.newItems) && data.newItems.length > 0) {
        const newOnes: NewsItem[] = data.newItems;
        setFeedItems((prev) => {
          const existingIds = new Set(prev.map((p) => p.id));
          const toAdd = newOnes.filter((n) => !existingIds.has(n.id));
          if (toAdd.length === 0) return prev;

          const updated = [...toAdd, ...prev];
          try {
            localStorage.setItem('breakpulse_all_headlines', JSON.stringify(updated));
          } catch {}
          return updated;
        });

        // Trigger notification & sweet breaking sound
        if (!isMuted) soundEngine.playBreakingChime();
        setFreshNewsToast(`🔴 New Breaking Dispatch: ${newOnes[0].source} - ${newOnes[0].title.slice(0, 50)}...`);
        setTimeout(() => setFreshNewsToast(null), 5000);
      }
    } catch (err) {
      // Quiet background handler
    }
  };

  useEffect(() => {
    fetchFeed(false);

    // Live news poll every 2 minutes for real-time dispatches
    const freshPollTimer = setInterval(() => {
      pollFreshInternetNews();
    }, 120 * 1000);

    return () => clearInterval(freshPollTimer);
  }, [isMuted]);

  // Combine live wire items with custom admin dispatches (pinned stories first)
  const allCombinedStories = [...customStories, ...feedItems];

  // Filter items by bureau if chosen
  const bureauFilteredItems = allCombinedStories.filter((item) =>
    selectedSource === 'all' ? true : item.sourceCode === selectedSource
  );

  // 5-Second Automated Pulse Engine:
  // Rotates headlines every 5 seconds, plays sweet gentle acoustic chime, triggers visual flash!
  useEffect(() => {
    if (isPaused || bureauFilteredItems.length === 0) return;

    const interval = setInterval(() => {
      setActivePulseIndex((prev) => {
        const next = (prev + 1) % bureauFilteredItems.length;
        if (!isMuted) soundEngine.playTickerPulse();
        // Visual flash in tandem with sweet acoustic chime
        setIsJustUpdated(true);
        setTimeout(() => setIsJustUpdated(false), 1200);
        return next;
      });
    }, pulseIntervalSec * 1000);

    return () => clearInterval(interval);
  }, [isPaused, pulseIntervalSec, bureauFilteredItems.length, isMuted]);

  const currentHeadline =
    bureauFilteredItems[activePulseIndex] || bureauFilteredItems[0] || null;

  // Handle headline click: mark as read and open Full Story Detail
  const handleSelectStory = (item: NewsItem) => {
    const updated = allCombinedStories.map((fi) => (fi.id === item.id ? { ...fi, read: true } : fi));
    setFeedItems(updated.filter((i) => !i.id.startsWith('breakpulse-custom-')));
    try {
      localStorage.setItem('breakpulse_all_headlines', JSON.stringify(updated));
    } catch {}

    setSelectedItemForDetail({ ...item, read: true });
  };

  // Handle AI Summary click
  const handleOpenSummary = (item: NewsItem) => {
    const updated = allCombinedStories.map((fi) => (fi.id === item.id ? { ...fi, read: true } : fi));
    setFeedItems(updated.filter((i) => !i.id.startsWith('breakpulse-custom-')));
    try {
      localStorage.setItem('breakpulse_all_headlines', JSON.stringify(updated));
    } catch {}

    setSelectedItemForSummary({ ...item, read: true });
  };

  // Toggle Bookmark
  const handleToggleBookmark = (id: string) => {
    setBookmarkedIds((prev) => {
      const exists = prev.includes(id);
      const next = exists ? prev.filter((bId) => bId !== id) : [...prev, id];
      try {
        localStorage.setItem('breakpulse_bookmarks', JSON.stringify(next));
      } catch {}
      return next;
    });
  };

  // Toggle Mute
  const handleToggleMute = () => {
    const next = !isMuted;
    setIsMuted(next);
    soundEngine.setMuted(next);
    try {
      localStorage.setItem('breakpulse_muted', String(next));
    } catch {}
  };

  // Toggle Language
  const handleToggleLanguage = () => {
    const next = !preferUrdu;
    setPreferUrdu(next);
    try {
      localStorage.setItem('breakpulse_prefer_urdu', String(next));
    } catch {}
  };

  // Mark all as read
  const handleMarkAllRead = () => {
    const updated = feedItems.map((i) => ({ ...i, read: true }));
    setFeedItems(updated);
    try {
      localStorage.setItem('breakpulse_all_headlines', JSON.stringify(updated));
    } catch {}
  };

  // Admin CMS: Update Admin Settings on server & sync all devices
  const handleUpdateAdminSettings = async (settings: AdminSettingsState) => {
    setAdminSettings(settings);
    try {
      localStorage.setItem('breakpulse_admin_config', JSON.stringify(settings));
      await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      });
    } catch (e) {
      console.warn('Sync admin settings error:', e);
    }
  };

  // Admin CMS: Publish custom pinned story to server & sync all devices
  const handlePublishCustomStory = async (story: NewsItem) => {
    const next = [story, ...customStories];
    setCustomStories(next);
    setFeedItems((prev) => [story, ...prev.filter((p) => p.id !== story.id)]);
    soundEngine.playBreakingChime();

    try {
      localStorage.setItem('breakpulse_custom_stories', JSON.stringify(next));
      await fetch('/api/admin/story', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(story),
      });
    } catch (e) {
      console.warn('Sync publish error:', e);
    }
  };

  // Admin CMS: Delete custom story on server & sync all devices
  const handleDeleteCustomStory = async (id: string) => {
    const next = customStories.filter((s) => s.id !== id);
    setCustomStories(next);
    setFeedItems((prev) => prev.filter((p) => p.id !== id));

    try {
      localStorage.setItem('breakpulse_custom_stories', JSON.stringify(next));
      await fetch(`/api/admin/story/${id}`, {
        method: 'DELETE',
      });
    } catch (e) {
      console.warn('Sync delete error:', e);
    }
  };

  // Admin CMS: Toggle Pin / Unpin story on server & sync all devices
  const handleTogglePinStory = async (id: string) => {
    const next = customStories.map((s) => (s.id === id ? { ...s, isPinned: !s.isPinned } : s));
    setCustomStories(next);
    setFeedItems((prev) => prev.map((s) => (s.id === id ? { ...s, isPinned: !s.isPinned } : s)));

    try {
      localStorage.setItem('breakpulse_custom_stories', JSON.stringify(next));
      await fetch(`/api/admin/story/${id}/pin`, {
        method: 'POST',
      });
    } catch (e) {
      console.warn('Sync pin error:', e);
    }
  };

  // Reset headline history
  const handleClearHistory = () => {
    if (window.confirm('Reset all reading history and mark all headlines as unread?')) {
      const reset = feedItems.map((i) => ({ ...i, read: false }));
      setFeedItems(reset);
      try {
        localStorage.setItem('breakpulse_all_headlines', JSON.stringify(reset));
      } catch {}
    }
  };

  // Category filter based on active tab
  const getTabFilteredItems = () => {
    let list = bureauFilteredItems;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(
        (i) =>
          i.title.toLowerCase().includes(q) ||
          i.titleUrdu?.toLowerCase().includes(q) ||
          i.summary.toLowerCase().includes(q) ||
          i.location.toLowerCase().includes(q)
      );
    }

    if (activeNavTab === 'home') return list;
    if (activeNavTab === 'world-affairs') return list.filter((i) => i.category === 'World Affairs');
    if (activeNavTab === 'country-condition') return list.filter((i) => i.category === 'Country Condition');
    if (activeNavTab === 'economy') return list.filter((i) => i.category === 'Economy & Markets');
    if (activeNavTab === 'sports') return list.filter((i) => i.category === 'Sports');
    if (activeNavTab === 'tech') return list.filter((i) => i.category === 'Science & Tech');
    if (activeNavTab === 'bookmarks') return list.filter((i) => bookmarkedIds.includes(i.id));

    return list;
  };

  const displayedStories = getTabFilteredItems();
  const unreadCount = feedItems.filter((i) => !i.read).length;

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-900 flex flex-col font-sans">
      
      {/* Visual Toast Notification when Fresh Internet Breaking News is Ingested */}
      {freshNewsToast && (
        <div className="fixed top-14 left-1/2 -translate-x-1/2 z-50 bg-slate-900 text-white px-5 py-2.5 rounded-full shadow-2xl border border-red-500/50 flex items-center space-x-2 text-xs font-bold animate-in slide-in-from-top-4 duration-300">
          <span className="w-2 h-2 rounded-full bg-red-500 animate-ping"></span>
          <span>{freshNewsToast}</span>
        </div>
      )}

      {/* 1. TOP BREAKING NEWS BAR (BBC style, NO NUMBERING, with visual update pulse & direct AI Summary) */}
      <BreakingTicker
        headline={currentHeadline}
        isPaused={isPaused}
        onTogglePause={() => setIsPaused(!isPaused)}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
        onSelectStory={handleSelectStory}
        onOpenSummary={handleOpenSummary}
        onOpenSettings={() => setIsSettingsOpen(true)}
        preferUrdu={preferUrdu}
        customAlert={adminSettings.tickerAlert}
        isJustUpdated={isJustUpdated}
      />

      {/* 2. EDITORIAL BROADCAST HEADER MASTHEAD */}
      <EditorialHeader
        activeTab={activeNavTab}
        onSelectTab={(tab) => {
          setActiveNavTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        selectedSource={selectedSource}
        onSelectSource={(src) => setSelectedSource(src)}
        searchQuery={searchQuery}
        onSearchChange={(q) => setSearchQuery(q)}
        bookmarkedCount={bookmarkedIds.length}
        unreadCount={unreadCount}
        preferUrdu={preferUrdu}
        onToggleLanguage={handleToggleLanguage}
        onRefreshWire={() => {
          fetchFeed(true);
          pollFreshInternetNews();
        }}
        isRefreshing={isRefreshing}
        lastUpdated={lastSyncTime}
        onOpenSettings={() => setIsSettingsOpen(true)}
      />

      {/* 3. MAIN CONTENT CONTAINER */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-1 w-full">
        
        {/* VIEW 1: HOME (Broadsheet layout across all categories like major news sites) */}
        {activeNavTab === 'home' && (
          <BroadsheetHome
            items={displayedStories}
            onSelectStory={handleSelectStory}
            onOpenSummary={handleOpenSummary}
            onToggleBookmark={handleToggleBookmark}
            bookmarkedIds={bookmarkedIds}
            preferUrdu={preferUrdu}
            liveStreamUrl={adminSettings.liveStreamUrl}
            isStreamActive={adminSettings.isStreamActive}
            onNavigateToAllHeadlines={() => {
              setActiveNavTab('all-headlines');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {/* VIEW 2: CATEGORY SPECIFIC TABS (World Affairs, Country Condition, Economy, Sports, Tech) */}
        {activeNavTab !== 'home' && activeNavTab !== 'all-headlines' && activeNavTab !== 'bookmarks' && (
          <div className="space-y-8 animate-in fade-in duration-150">
            {/* Category Header */}
            <div className="border-b border-slate-200 pb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h2 className="text-2xl sm:text-3xl font-headline font-bold text-slate-900 flex items-center">
                  <span className="w-2 h-6 bg-[#bb1919] mr-2.5"></span>
                  {activeNavTab === 'world-affairs' && 'World Affairs Desk (عالمی امور)'}
                  {activeNavTab === 'country-condition' && 'Country Condition & National Affairs (ملکی حالات)'}
                  {activeNavTab === 'economy' && 'Economy, Markets & Central Banking (معیشت و تجارت)'}
                  {activeNavTab === 'sports' && 'Sports & Cricket Wire (کھیلوں کی دنیا)'}
                  {activeNavTab === 'tech' && 'Science, AI & Space Technology (سائنس و ٹیکنالوجی)'}
                </h2>
                <p className="text-xs text-slate-500 mt-1">
                  Verified reports cross-checked against primary governmental, regulatory, and wire releases.
                </p>
              </div>

              <span className="text-xs font-semibold text-slate-600 bg-white px-3 py-1 rounded border border-slate-200 self-start sm:self-center">
                {displayedStories.length} Verified Stories
              </span>
            </div>

            {/* Stories Grid */}
            <BroadsheetHome
              items={displayedStories}
              onSelectStory={handleSelectStory}
              onOpenSummary={handleOpenSummary}
              onToggleBookmark={handleToggleBookmark}
              bookmarkedIds={bookmarkedIds}
              preferUrdu={preferUrdu}
            />
          </div>
        )}

        {/* VIEW 3: ALL HEADLINES (Dedicated Archive Tab with Missed / Unread filter) */}
        {activeNavTab === 'all-headlines' && (
          <AllHeadlinesTab
            headlines={allCombinedStories}
            onSelectStory={handleSelectStory}
            onOpenSummary={handleOpenSummary}
            onMarkAllRead={handleMarkAllRead}
            preferUrdu={preferUrdu}
          />
        )}

        {/* VIEW 4: SAVED BOOKMARKS */}
        {activeNavTab === 'bookmarks' && (
          <div className="space-y-6">
            <div className="border-b border-slate-200 pb-3 flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-headline font-bold text-slate-900 flex items-center">
                  <Bookmark className="w-5 h-5 mr-2 text-[#bb1919]" />
                  Saved Reading List ({bookmarkedIds.length} Stories)
                </h2>
                <p className="text-xs text-slate-500">
                  Articles saved to your local browser library for offline reading and review.
                </p>
              </div>
            </div>

            {displayedStories.length === 0 ? (
              <div className="py-24 text-center rounded-2xl bg-white border border-slate-200 text-slate-500 space-y-2">
                <Bookmark className="w-8 h-8 mx-auto text-slate-300" />
                <p className="font-bold text-sm">No bookmarked stories yet.</p>
                <p className="text-xs text-slate-400">
                  Click the bookmark icon on any headline card to save it here.
                </p>
              </div>
            ) : (
              <BroadsheetHome
                items={displayedStories}
                onSelectStory={handleSelectStory}
                onOpenSummary={handleOpenSummary}
                onToggleBookmark={handleToggleBookmark}
                bookmarkedIds={bookmarkedIds}
                preferUrdu={preferUrdu}
              />
            )}
          </div>
        )}

      </main>

      {/* 4. FOOTER (Broadsheet news style) */}
      <footer className="border-t border-slate-200 bg-white mt-16 text-slate-600 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center space-x-2.5">
              <div className="w-7 h-7 bg-[#bb1919] flex items-center justify-center text-white font-headline font-bold text-sm">
                BP
              </div>
              <span className="font-headline font-bold text-slate-900 text-sm">
                BreakPulse News
              </span>
              <span className="text-slate-400">·</span>
              <span className="text-slate-500">Multi-Bureau Verified Editorial Desk</span>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-5 font-semibold text-slate-700">
              <span>🇵🇰 Geo News</span>
              <span>🇬🇧 BBC World</span>
              <span>🇺🇸 CNN International</span>
              <span>🇺🇸 Fox News</span>
              <span>🇨🇳 CCTV / CGTN</span>
            </div>

            <div className="flex items-center space-x-3">
              <button
                onClick={() => setIsSettingsOpen(true)}
                className="text-slate-500 hover:text-slate-900 font-semibold underline"
              >
                BreakPulse Admin & Settings
              </button>
            </div>
          </div>
        </div>
      </footer>

      {/* 5. MODAL: AI SUMMARY DRAWER / MODAL */}
      {selectedItemForSummary && (
        <AISummaryModal
          item={selectedItemForSummary}
          onClose={() => setSelectedItemForSummary(null)}
          onOpenFullDetail={handleSelectStory}
          onToggleBookmark={handleToggleBookmark}
          isBookmarked={bookmarkedIds.includes(selectedItemForSummary.id)}
          preferUrdu={preferUrdu}
        />
      )}

      {/* 6. MODAL: FULL COMPREHENSIVE STORY DOSSIER */}
      {selectedItemForDetail && (
        <AIDetailModal
          item={selectedItemForDetail}
          onClose={() => setSelectedItemForDetail(null)}
          onOpenSummary={handleOpenSummary}
          onToggleBookmark={handleToggleBookmark}
          isBookmarked={bookmarkedIds.includes(selectedItemForDetail.id)}
          preferUrdu={preferUrdu}
        />
      )}

      {/* 7. MODAL: SETTINGS & BREAKPULSE ADMIN CMS */}
      <SettingsAdminModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        pulseIntervalSec={pulseIntervalSec}
        onChangeInterval={(sec) => setPulseIntervalSec(sec)}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
        preferUrdu={preferUrdu}
        onToggleLanguage={handleToggleLanguage}
        onClearHistory={handleClearHistory}
        adminSettings={adminSettings}
        onUpdateAdminSettings={handleUpdateAdminSettings}
        onPublishCustomStory={handlePublishCustomStory}
        onDeleteCustomStory={handleDeleteCustomStory}
        onTogglePinStory={handleTogglePinStory}
        customStories={customStories}
      />

    </div>
  );
}
