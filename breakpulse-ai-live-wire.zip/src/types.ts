export type SourceCode = 'all' | 'geo' | 'bbc' | 'cnn' | 'fox' | 'cctv';

export type MainNavTab =
  | 'home'
  | 'world-affairs'
  | 'country-condition'
  | 'economy'
  | 'sports'
  | 'tech'
  | 'all-headlines'
  | 'bookmarks';

export type UrgencyType = 'BREAKING' | 'DEVELOPING' | 'EXCLUSIVE' | 'ANALYSIS';

export interface VerificationInfo {
  status: 'VERIFIED' | 'CROSS_CHECKED' | 'DEVELOPING';
  confidenceScore: number; // e.g. 98%
  confirmedBy: Array<'Geo News' | 'BBC World' | 'CNN' | 'Fox News' | 'CCTV'>;
  primaryOutlet: string;
  notes: string;
}

export interface NewsItem {
  id: string;
  title: string;
  titleUrdu: string;
  source: 'Geo News' | 'BBC World' | 'CNN' | 'Fox News' | 'CCTV';
  sourceCode: 'geo' | 'bbc' | 'cnn' | 'fox' | 'cctv';
  category: 'World Affairs' | 'Country Condition' | 'Economy & Markets' | 'Sports' | 'Science & Tech';
  urgency: UrgencyType;
  timestamp: string;
  displayTime: string;
  summary: string;
  summaryUrdu: string;
  location: string;
  tags: string[];
  read: boolean;
  bookmarked?: boolean;
  imageUrl: string; // Every story has an image as requested
  verification: VerificationInfo;
  isPinned?: boolean;
  pinDuration?: 'always' | '1h' | '6h' | '24h';
  pinExpiryTimestamp?: number | null;
  fullStoryParagraphs?: string[];
  bulletSummary?: string[];
  keyTakeaway?: string;
  isCustomAdmin?: boolean;
}

export interface NetworkConfig {
  code: 'geo' | 'bbc' | 'cnn' | 'fox' | 'cctv';
  name: string;
  region: string;
  brandColor: string;
  flag: string;
}

export interface AIDetail {
  headline: string;
  executiveSummary: string;
  leadParagraph: string;
  fullArticleText: string[];
  keyFacts: string[];
  networkPerspectives: {
    geoPerspective: string;
    bbcPerspective: string;
    cnnPerspective: string;
    foxPerspective: string;
    cctvPerspective: string;
  };
  timeline: Array<{ time: string; event: string }>;
  quotes: Array<{ speaker: string; title: string; statement: string }>;
  geopoliticalImpact: string;
  marketReaction: string;
  urduSummary: string;
  urduFullText?: string[];
  verificationReport: {
    verdict: string;
    corroboratingBureaus: string[];
    discrepanciesFound: string;
  };
}

export interface AISummaryResponse {
  headline: string;
  bulletPoints: string[];
  keyTakeaway: string;
  urduBulletPoints: string[];
  urduKeyTakeaway: string;
  readTime: string;
}

export interface AdminSettingsState {
  adminPasscode: string;
  tickerAlert: string;
  liveStreamUrl: string;
  selectedPresetStream: string;
  isStreamActive: boolean;
}
