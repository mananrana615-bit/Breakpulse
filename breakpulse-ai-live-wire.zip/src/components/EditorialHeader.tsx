import React from 'react';
import {
  Globe2,
  Bookmark,
  RefreshCw,
  Search,
  ShieldCheck,
  Languages,
  Radio,
  Archive,
  Settings,
  Shield
} from 'lucide-react';
import { MainNavTab, SourceCode } from '../types';

interface EditorialHeaderProps {
  activeTab: MainNavTab;
  onSelectTab: (tab: MainNavTab) => void;
  selectedSource: SourceCode;
  onSelectSource: (src: SourceCode) => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  bookmarkedCount: number;
  unreadCount: number;
  preferUrdu: boolean;
  onToggleLanguage: () => void;
  onRefreshWire: () => void;
  isRefreshing: boolean;
  lastUpdated: string;
  onOpenSettings: () => void;
}

export const EditorialHeader: React.FC<EditorialHeaderProps> = ({
  activeTab,
  onSelectTab,
  selectedSource,
  onSelectSource,
  searchQuery,
  onSearchChange,
  bookmarkedCount,
  unreadCount,
  preferUrdu,
  onToggleLanguage,
  onRefreshWire,
  isRefreshing,
  lastUpdated,
  onOpenSettings,
}) => {
  const currentDate = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const navCategories: Array<{ id: MainNavTab; label: string; urduLabel: string }> = [
    { id: 'home', label: 'Home', urduLabel: 'مرکزی صفحہ' },
    { id: 'world-affairs', label: 'World Affairs', urduLabel: 'عالمی امور' },
    { id: 'country-condition', label: 'Country Condition', urduLabel: 'ملکی حالات' },
    { id: 'economy', label: 'Economy & Markets', urduLabel: 'معیشت و تجارت' },
    { id: 'sports', label: 'Sports', urduLabel: 'کھیل' },
    { id: 'tech', label: 'Science & Tech', urduLabel: 'سائنس و ٹیکنالوجی' },
    { id: 'all-headlines', label: 'All Headlines', urduLabel: 'تمام سرخیاں' },
  ];

  return (
    <header className="bg-white border-b border-slate-200">
      
      {/* 1. Top Masthead Line: Date, Edition, Multi-bureau verification indicator */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2 border-b border-slate-100 flex flex-wrap items-center justify-between text-[11px] text-slate-500 gap-2">
        <div className="flex items-center space-x-3">
          <span className="font-medium">{currentDate}</span>
          <span className="text-slate-300">|</span>
          <span className="text-slate-600 font-semibold">Global & South Asia Edition</span>
          <span className="text-slate-300 hidden md:inline">|</span>
          <span className="hidden md:inline-flex items-center text-emerald-700 font-semibold">
            <ShieldCheck className="w-3.5 h-3.5 mr-1" />
            AI Multi-Bureau Fact Verification Active
          </span>
        </div>

        <div className="flex items-center space-x-3 text-slate-600 font-medium">
          <span className="hidden xl:inline text-slate-500 font-mono text-[10px]">
            PKR/USD 278.20 · KSE-100 89,450 ▲ · Gold $2,740 · Oil $78.10 · Islamabad 24°C ☀
          </span>
          <span className="hidden lg:inline text-slate-400">
            Bureaus: 🇵🇰 Geo · 🇬🇧 BBC · 🇺🇸 CNN · 🇺🇸 Fox · 🇨🇳 CCTV
          </span>
          <button
            onClick={onToggleLanguage}
            className="flex items-center space-x-1 text-slate-700 hover:text-slate-900 font-bold px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 transition"
          >
            <Languages className="w-3.5 h-3.5 text-emerald-600" />
            <span>{preferUrdu ? 'English Version' : 'اردو ورژن'}</span>
          </button>
        </div>
      </div>

      {/* 2. Main Title Masthead */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        
        {/* Brand Name */}
        <div className="flex items-center space-x-3.5">
          <div className="w-11 h-11 bg-[#bb1919] flex items-center justify-center text-white font-headline font-black text-2xl shadow-sm tracking-tighter">
            BP
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-2xl sm:text-3xl font-black font-headline tracking-tight text-slate-900">
                BreakPulse <span className="text-[#bb1919]">News</span>
              </h1>
              <span className="text-[10px] uppercase font-bold tracking-widest px-1.5 py-0.5 bg-slate-900 text-white rounded">
                Verified Wire
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium">
              Real-Time Cross-Verified Intelligence from Geo News, BBC, CNN, Fox & CCTV
            </p>
          </div>
        </div>

        {/* Right Utilities: Search, Bookmarks, Settings, Sync Wire */}
        <div className="flex items-center space-x-2 w-full md:w-auto justify-end">
          {/* Search bar */}
          <div className="relative flex-1 md:w-60">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Search news, topics..."
              className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-slate-400 focus:bg-white"
            />
          </div>

          {/* Bookmarks */}
          <button
            onClick={() => onSelectTab('bookmarks')}
            className={`px-3 py-1.5 rounded-lg border text-xs font-semibold flex items-center space-x-1.5 transition ${
              activeTab === 'bookmarks'
                ? 'bg-slate-900 text-white border-slate-900'
                : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200'
            }`}
            title="Saved Bookmarks"
          >
            <Bookmark className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Saved</span>
            <span className="text-[10px] font-mono text-slate-400 font-bold">({bookmarkedCount})</span>
          </button>

          {/* Settings & Admin CMS Button */}
          <button
            onClick={onOpenSettings}
            className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold flex items-center space-x-1 transition"
            title="Settings & BreakPulse Admin CMS"
          >
            <Settings className="w-3.5 h-3.5 text-slate-600" />
            <span className="hidden md:inline">Settings</span>
          </button>

          {/* Sync Wire */}
          <button
            onClick={onRefreshWire}
            disabled={isRefreshing}
            className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-700 transition"
            title="Refresh Wire with Gemini Google Search"
          >
            <RefreshCw className={`w-4 h-4 text-slate-600 ${isRefreshing ? 'animate-spin' : ''}`} />
          </button>
        </div>

      </div>

      {/* 3. Primary Category Navigation Tabs */}
      <nav className="border-t border-slate-200 bg-[#fafafa]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between overflow-x-auto scrollbar-none">
          <div className="flex items-center space-x-1 sm:space-x-2 py-1">
            {navCategories.map((cat) => {
              const isActive = activeTab === cat.id;

              return (
                <button
                  key={cat.id}
                  onClick={() => onSelectTab(cat.id)}
                  className={`px-3 py-2 text-xs sm:text-sm font-bold whitespace-nowrap transition-colors border-b-2 flex items-center space-x-1.5 ${
                    isActive
                      ? 'border-[#bb1919] text-[#bb1919] bg-white'
                      : 'border-transparent text-slate-700 hover:text-slate-950 hover:border-slate-300'
                  }`}
                >
                  <span>{preferUrdu ? cat.urduLabel : cat.label}</span>
                  {cat.id === 'all-headlines' && unreadCount > 0 && (
                    <span className="px-1.5 py-0.2 rounded-full text-[10px] font-mono font-bold bg-[#bb1919] text-white">
                      {unreadCount}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Channel Filter Pills in Nav */}
          <div className="hidden lg:flex items-center space-x-1 text-xs border-l border-slate-200 pl-4 py-1">
            <span className="text-slate-400 text-[11px] font-semibold mr-1">Bureau:</span>
            {[
              { code: 'all', label: 'All' },
              { code: 'geo', label: 'Geo' },
              { code: 'bbc', label: 'BBC' },
              { code: 'cnn', label: 'CNN' },
              { code: 'fox', label: 'Fox' },
              { code: 'cctv', label: 'CCTV' },
            ].map((ch) => (
              <button
                key={ch.code}
                onClick={() => onSelectSource(ch.code as SourceCode)}
                className={`px-2 py-1 rounded text-xs font-semibold transition ${
                  selectedSource === ch.code
                    ? 'bg-slate-900 text-white'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                {ch.label}
              </button>
            ))}
          </div>
        </div>
      </nav>

    </header>
  );
};
