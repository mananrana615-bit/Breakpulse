import React from 'react';
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Sparkles,
  Settings,
  ShieldAlert
} from 'lucide-react';
import { NewsItem } from '../types';
import { NETWORKS } from '../utils/constants';

interface BreakingTickerProps {
  headline: NewsItem | null;
  isPaused: boolean;
  onTogglePause: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  onSelectStory: (item: NewsItem) => void;
  onOpenSummary: (item: NewsItem) => void;
  onOpenSettings: () => void;
  preferUrdu: boolean;
  customAlert?: string;
  isJustUpdated?: boolean;
}

export const BreakingTicker: React.FC<BreakingTickerProps> = ({
  headline,
  isPaused,
  onTogglePause,
  isMuted,
  onToggleMute,
  onSelectStory,
  onOpenSummary,
  onOpenSettings,
  preferUrdu,
  customAlert,
  isJustUpdated = false,
}) => {
  if (!headline && !customAlert) return null;

  const network = headline ? NETWORKS[headline.sourceCode] || NETWORKS.geo : null;

  return (
    <div className="h-12 bg-[#bb1919] text-white sticky top-0 z-40 border-b border-[#a01515] shadow-xs select-none overflow-hidden">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 h-full flex items-center justify-between gap-2 sm:gap-4">
        
        {/* Left: Fixed-width badge that never pushes or causes layout shift */}
        <div className="flex-shrink-0 flex items-center space-x-1.5 sm:space-x-2">
          <div className={`px-2 py-1 rounded text-[10px] sm:text-xs font-black uppercase tracking-wider flex items-center space-x-1.5 transition-colors duration-200 ${
            isJustUpdated ? 'bg-white text-[#bb1919]' : 'bg-black/30 text-white'
          }`}>
            <span className={`w-2 h-2 rounded-full ${isJustUpdated ? 'bg-[#bb1919] animate-ping' : 'bg-red-400 animate-pulse'}`} />
            <span>{isJustUpdated ? 'UPDATE' : customAlert ? 'ALERT' : 'BREAKING'}</span>
          </div>

          {headline && !customAlert && network && (
            <span className="hidden sm:inline-flex items-center text-[11px] font-bold text-white/90 bg-white/10 px-2 py-0.5 rounded">
              <span className="mr-1">{network.flag}</span>
              <span>{headline.source}</span>
            </span>
          )}
        </div>

        {/* Center: Rock-solid Headline (strictly fixed height, zero resizing or page bounce) */}
        <div
          onClick={() => {
            if (headline) onSelectStory(headline);
          }}
          className="flex-1 min-w-0 h-full flex items-center cursor-pointer hover:underline overflow-hidden"
          title="Click to view full journalistic story"
        >
          {customAlert ? (
            <span className="font-bold text-xs sm:text-sm text-amber-200 truncate flex items-center">
              <ShieldAlert className="w-3.5 h-3.5 inline mr-1 text-white flex-shrink-0" />
              <span className="truncate">{customAlert}</span>
            </span>
          ) : headline ? (
            <span
              key={headline.id}
              className={`truncate text-xs sm:text-sm font-semibold text-white/95 leading-tight block w-full transition-opacity duration-200 ${
                preferUrdu && headline.titleUrdu ? 'font-urdu' : ''
              }`}
            >
              {preferUrdu && headline.titleUrdu ? headline.titleUrdu : headline.title}
            </span>
          ) : null}
        </div>

        {/* Right: Quick Actions (AI Summary, Pause, Mute, Settings) */}
        <div className="flex-shrink-0 flex items-center space-x-1 sm:space-x-2">
          {headline && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onOpenSummary(headline);
              }}
              className="px-2.5 py-1 rounded bg-white text-[#bb1919] hover:bg-slate-100 font-bold text-[10px] sm:text-[11px] transition flex items-center space-x-1 shadow-xs flex-shrink-0"
              title="Generate Instant AI Summary"
            >
              <Sparkles className="w-3 h-3 text-amber-600" />
              <span>AI Summary</span>
            </button>
          )}

          {/* Pause / Resume Ticker */}
          <button
            onClick={onTogglePause}
            className="p-1.5 rounded text-white/80 hover:text-white hover:bg-black/20 transition flex-shrink-0"
            title={isPaused ? 'Resume 5s news ticker' : 'Pause ticker'}
          >
            {isPaused ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
          </button>

          {/* Mute / Unmute */}
          <button
            onClick={onToggleMute}
            className="p-1.5 rounded text-white/80 hover:text-white hover:bg-black/20 transition flex-shrink-0"
            title={isMuted ? 'Unmute sweet acoustic chime' : 'Mute ticker sound'}
          >
            {isMuted ? <VolumeX className="w-3.5 h-3.5 text-white/50" /> : <Volume2 className="w-3.5 h-3.5" />}
          </button>

          {/* Settings Modal */}
          <button
            onClick={onOpenSettings}
            className="p-1.5 rounded text-white/80 hover:text-white hover:bg-black/20 transition flex-shrink-0"
            title="Portal Settings & BreakPulse Admin CMS"
          >
            <Settings className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </div>
  );
};
