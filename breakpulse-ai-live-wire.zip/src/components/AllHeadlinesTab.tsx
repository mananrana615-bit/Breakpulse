import React, { useState } from 'react';
import {
  Archive,
  CheckCircle,
  EyeOff,
  Search,
  Sparkles,
  Clock,
  MapPin,
  Download,
  Filter,
  ShieldCheck
} from 'lucide-react';
import { NewsItem, SourceCode } from '../types';
import { NETWORKS } from '../utils/constants';

interface AllHeadlinesTabProps {
  headlines: NewsItem[];
  onSelectStory: (item: NewsItem) => void;
  onOpenSummary: (item: NewsItem) => void;
  onMarkAllRead: () => void;
  preferUrdu: boolean;
}

export const AllHeadlinesTab: React.FC<AllHeadlinesTabProps> = ({
  headlines,
  onSelectStory,
  onOpenSummary,
  onMarkAllRead,
  preferUrdu,
}) => {
  const [readFilter, setReadFilter] = useState<'unread' | 'all' | 'read'>('unread'); // Defaults to 'unread' so user immediately sees what they missed!
  const [sourceFilter, setSourceFilter] = useState<SourceCode>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const totalCount = headlines.length;
  const unreadCount = headlines.filter((h) => !h.read).length;
  const readCount = totalCount - unreadCount;

  const filteredHeadlines = headlines.filter((item) => {
    if (readFilter === 'unread' && item.read) return false;
    if (readFilter === 'read' && !item.read) return false;
    if (sourceFilter !== 'all' && item.sourceCode !== sourceFilter) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = item.title.toLowerCase().includes(q);
      const matchUrdu = item.titleUrdu?.toLowerCase().includes(q);
      const matchLoc = item.location.toLowerCase().includes(q);
      if (!matchTitle && !matchUrdu && !matchLoc) return false;
    }
    return true;
  });

  const handleExportJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(headlines, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `breakpulse-headlines-${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-6 bg-[#bb1919] rounded-xs"></span>
            <h2 className="text-xl sm:text-2xl font-headline font-bold text-slate-900">
              All Headlines Archive (آرکائیو اور چھوڑی ہوئی سرخیاں)
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-600">
            Daily log of all wire headlines across Geo News, BBC, CNN, Fox & CCTV. Easily review any stories you skipped or missed earlier.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={onMarkAllRead}
            disabled={unreadCount === 0}
            className="px-3.5 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition flex items-center space-x-1.5 disabled:opacity-50"
          >
            <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
            <span>Mark All as Read</span>
          </button>

          <button
            onClick={handleExportJSON}
            className="px-3.5 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition flex items-center space-x-1.5"
          >
            <Download className="w-3.5 h-3.5 text-slate-600" />
            <span>Export Archive</span>
          </button>
        </div>
      </div>

      {/* Filter and Control Desk */}
      <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          
          {/* Missed vs Read Pill Toggle */}
          <div className="flex items-center space-x-1 bg-slate-100 p-1 rounded-lg text-xs font-bold">
            <button
              onClick={() => setReadFilter('unread')}
              className={`px-3 py-1.5 rounded-md transition flex items-center space-x-1.5 ${
                readFilter === 'unread'
                  ? 'bg-[#bb1919] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <EyeOff className="w-3.5 h-3.5" />
              <span>Missed / Unread ({unreadCount})</span>
            </button>

            <button
              onClick={() => setReadFilter('all')}
              className={`px-3 py-1.5 rounded-md transition ${
                readFilter === 'all'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Today ({totalCount})
            </button>

            <button
              onClick={() => setReadFilter('read')}
              className={`px-3 py-1.5 rounded-md transition flex items-center space-x-1.5 ${
                readFilter === 'read'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <CheckCircle className="w-3.5 h-3.5" />
              <span>Read ({readCount})</span>
            </button>
          </div>

          {/* Search box */}
          <div className="relative flex-1 max-w-sm">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search archived headlines..."
              className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-slate-400 focus:bg-white"
            />
          </div>
        </div>

        {/* Channel Filter Pills */}
        <div className="flex items-center space-x-1.5 overflow-x-auto pt-2 border-t border-slate-100 text-xs">
          <span className="text-slate-400 font-semibold text-[11px] mr-1">Bureau:</span>
          {[
            { code: 'all', label: 'All Bureaus' },
            { code: 'geo', label: '🇵🇰 Geo News' },
            { code: 'bbc', label: '🇬🇧 BBC World' },
            { code: 'cnn', label: '🇺🇸 CNN' },
            { code: 'fox', label: '🇺🇸 Fox News' },
            { code: 'cctv', label: '🇨🇳 CCTV' },
          ].map((ch) => (
            <button
              key={ch.code}
              onClick={() => setSourceFilter(ch.code as SourceCode)}
              className={`px-2.5 py-1 rounded text-xs font-semibold transition ${
                sourceFilter === ch.code
                  ? 'bg-slate-900 text-white'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              {ch.label}
            </button>
          ))}
        </div>
      </div>

      {/* Headlines List */}
      <div className="space-y-3">
        {filteredHeadlines.length === 0 ? (
          <div className="py-20 text-center rounded-2xl bg-white border border-slate-200 text-slate-500 space-y-2">
            <CheckCircle className="w-8 h-8 text-emerald-600 mx-auto" />
            <p className="font-bold text-sm">
              {readFilter === 'unread'
                ? 'All caught up! You have read all wire headlines.'
                : 'No headlines found matching the selected filter.'}
            </p>
          </div>
        ) : (
          filteredHeadlines.map((item) => {
            const net = NETWORKS[item.sourceCode] || NETWORKS.bbc;

            return (
              <div
                key={item.id}
                className={`p-4 rounded-xl border transition flex items-start justify-between gap-3.5 group ${
                  !item.read
                    ? 'bg-white border-l-4 border-l-[#bb1919] border-slate-200 shadow-xs'
                    : 'bg-[#fafafa] border-slate-200 opacity-85 hover:opacity-100'
                }`}
              >
                <div className="space-y-2 flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                    {!item.read && (
                      <span className="font-bold text-[10px] uppercase text-[#bb1919] bg-red-50 px-1.5 py-0.5 rounded border border-red-200">
                        Missed
                      </span>
                    )}
                    <span className="font-semibold text-slate-800">{net.flag} {item.source}</span>
                    <span>·</span>
                    <span className="font-medium text-slate-600">{item.category}</span>
                    <span>·</span>
                    <span><Clock className="w-3 h-3 inline mr-0.5 text-slate-400" />{item.displayTime}</span>
                    <span>·</span>
                    <span>{item.location}</span>
                  </div>

                  <h3
                    onClick={() => onSelectStory(item)}
                    className="font-headline font-bold text-base text-slate-900 group-hover:text-[#bb1919] transition cursor-pointer leading-snug line-clamp-2"
                  >
                    {preferUrdu && item.titleUrdu ? item.titleUrdu : item.title}
                  </h3>

                  <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                    {item.summary}
                  </p>

                  {/* Actions */}
                  <div className="flex items-center space-x-2 pt-1">
                    <button
                      onClick={() => onOpenSummary(item)}
                      className="px-2.5 py-1 rounded bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 text-xs font-bold transition flex items-center space-x-1"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                      <span>AI Summary</span>
                    </button>

                    <button
                      onClick={() => onSelectStory(item)}
                      className="px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-900 text-xs font-bold transition"
                    >
                      Full Story
                    </button>
                  </div>
                </div>

                {/* Right Thumbnail Image */}
                <div
                  className="w-20 h-20 sm:w-24 sm:h-24 rounded-lg overflow-hidden bg-slate-100 border border-slate-200 flex-shrink-0 cursor-pointer"
                  onClick={() => onSelectStory(item)}
                >
                  <img
                    src={item.imageUrl || 'https://images.unsplash.com/photo-1504711434969-e33886168f5c?auto=format&fit=crop&w=400&q=80'}
                    alt={item.title}
                    onError={(e) => {
                      (e.target as HTMLImageElement).src =
                        'https://images.unsplash.com/photo-1541872703-74c5e44368f9?auto=format&fit=crop&w=400&q=80';
                    }}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                  />
                </div>
              </div>
            );
          })
        )}
      </div>

    </div>
  );
};
