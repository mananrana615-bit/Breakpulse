import React, { useState, useEffect } from 'react';
import {
  X,
  Volume2,
  VolumeX,
  Sparkles,
  Bookmark,
  Share2,
  CheckCircle2,
  Clock,
  MapPin,
  ShieldCheck,
  FileText,
  Layers,
  Quote,
  TrendingUp,
  Languages,
  Radio,
  BookOpen
} from 'lucide-react';
import { NewsItem, AIDetail } from '../types';
import { NETWORKS } from '../utils/constants';

interface AIDetailModalProps {
  item: NewsItem | null;
  onClose: () => void;
  onOpenSummary: (item: NewsItem) => void;
  onToggleBookmark: (id: string) => void;
  isBookmarked: boolean;
  preferUrdu: boolean;
}

export const AIDetailModal: React.FC<AIDetailModalProps> = ({
  item,
  onClose,
  onOpenSummary,
  onToggleBookmark,
  isBookmarked,
  preferUrdu,
}) => {
  const [loading, setLoading] = useState<boolean>(true);
  const [detail, setDetail] = useState<AIDetail | null>(null);
  const [activeTab, setActiveTab] = useState<'story' | 'facts' | 'perspectives' | 'timeline' | 'urdu'>(
    preferUrdu ? 'urdu' : 'story'
  );
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  useEffect(() => {
    if (!item) return;

    let isMounted = true;
    setLoading(true);
    setDetail(null);
    setIsPlayingAudio(false);

    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }

    // Call server Gemini API for complete, multi-paragraph journalistic report
    fetch('/api/news/detail', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        headline: item.title,
        source: item.source,
        category: item.category,
        location: item.location,
      }),
    })
      .then((res) => res.json())
      .then((data) => {
        if (isMounted) {
          if (data.detail) {
            setDetail(data.detail);
          }
          setLoading(false);
        }
      })
      .catch((err) => {
        console.error('Failed to load detail dossier:', err);
        if (isMounted) setLoading(false);
      });

    return () => {
      isMounted = false;
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, [item]);

  if (!item) return null;

  const network = NETWORKS[item.sourceCode] || NETWORKS.bbc;

  const handleToggleSpeech = () => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    if (isPlayingAudio) {
      window.speechSynthesis.cancel();
      setIsPlayingAudio(false);
      return;
    }

    const textToRead = detail
      ? `${item.source} verified report. ${detail.headline}. ${detail.executiveSummary} ${detail.fullArticleText?.slice(0, 2).join(' ') || detail.leadParagraph}`
      : `${item.source} report. ${item.title}. ${item.summary}`;

    const utterance = new SpeechSynthesisUtterance(textToRead);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    utterance.onend = () => setIsPlayingAudio(false);
    utterance.onerror = () => setIsPlayingAudio(false);

    setIsPlayingAudio(true);
    window.speechSynthesis.speak(utterance);
  };

  const handleCopyReport = () => {
    if (!detail) return;
    const text = `BREAKPULSE VERIFIED FULL REPORT\n${item.source} (${item.location})\n${detail.headline}\n\n${detail.fullArticleText?.join('\n\n') || detail.leadParagraph}\n\nKEY VERIFIED FACTS:\n${detail.keyFacts.map((f, i) => `${i + 1}. ${f}`).join('\n')}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const paragraphsToRender = detail?.fullArticleText && detail.fullArticleText.length >= 2
    ? detail.fullArticleText
    : item.fullStoryParagraphs && item.fullStoryParagraphs.length >= 2
    ? item.fullStoryParagraphs
    : detail?.leadParagraph
    ? [detail.leadParagraph, detail.executiveSummary]
    : [item.summary];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/75 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative w-full max-w-4xl max-h-[92vh] bg-white border border-slate-300 rounded-2xl shadow-2xl overflow-hidden text-slate-900 flex flex-col">
        
        {/* Top Header Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-[#f8fafc]">
          <div className="flex items-center space-x-2.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#bb1919] animate-pulse"></span>
            <div className="flex items-center space-x-2">
              <span className="font-extrabold text-xs uppercase tracking-wider text-[#bb1919] bg-red-50 px-2 py-0.5 rounded border border-red-200">
                Full Newsroom Report
              </span>
              <span className="text-xs font-bold text-slate-700">
                {network.flag} {item.source}
              </span>
              <span className="text-xs text-slate-400 hidden sm:inline">·</span>
              <span className="text-xs text-slate-500 font-medium hidden sm:inline">
                {item.category}
              </span>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {/* Quick Switch to AI Summary */}
            <button
              onClick={() => {
                onClose();
                onOpenSummary(item);
              }}
              className="px-3 py-1.5 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 text-xs font-bold transition flex items-center space-x-1"
              title="Switch to brief AI summary"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>AI Summary (خلاصہ)</span>
            </button>

            <button
              onClick={handleCopyReport}
              className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition"
              title="Copy Story"
            >
              <Share2 className="w-4 h-4" />
            </button>

            <button
              onClick={() => onToggleBookmark(item.id)}
              className={`p-1.5 rounded-lg transition ${
                isBookmarked ? 'text-red-600 bg-red-50' : 'text-slate-500 hover:text-slate-800 hover:bg-slate-100'
              }`}
              title="Bookmark story"
            >
              <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`} />
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition"
              title="Close (Esc)"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8 space-y-6 overflow-y-auto flex-1">
          
          {/* Headline and Metadata */}
          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 font-medium">
              <span className="font-bold text-slate-900 uppercase">{item.category}</span>
              <span>·</span>
              <span><MapPin className="w-3.5 h-3.5 inline mr-1 text-slate-400" />{item.location}</span>
              <span>·</span>
              <span><Clock className="w-3.5 h-3.5 inline mr-1 text-slate-400" />{item.displayTime}</span>
              <span>·</span>
              <span className="inline-flex items-center text-emerald-800 font-semibold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                <ShieldCheck className="w-3.5 h-3.5 mr-1 text-emerald-600" />
                Verified ({item.verification.confirmedBy.join(', ')})
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-headline font-bold text-slate-900 leading-tight">
              {item.title}
            </h1>

            {item.titleUrdu && (
              <p className="text-emerald-800 font-urdu text-lg sm:text-xl dir-rtl text-right pt-1">
                {item.titleUrdu}
              </p>
            )}
          </div>

          {/* Lead Photo */}
          {item.imageUrl && (
            <div className="aspect-video w-full rounded-xl overflow-hidden bg-slate-100 border border-slate-200">
              <img
                src={item.imageUrl}
                alt={item.title}
                onError={(e) => {
                  (e.target as HTMLImageElement).src =
                    'https://images.unsplash.com/photo-1541872703-74c5e44368f9?auto=format&fit=crop&w=1200&q=80';
                }}
                className="w-full h-full object-cover"
              />
            </div>
          )}

          {/* Audio Anchor Bar */}
          <div className="flex flex-col sm:flex-row items-center justify-between p-3.5 rounded-xl bg-slate-50 border border-slate-200 gap-3">
            <div className="flex items-center space-x-3 w-full sm:w-auto">
              <div className="w-9 h-9 rounded-lg bg-[#bb1919] flex items-center justify-center text-white shadow-sm">
                <Radio className="w-4 h-4 animate-pulse" />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-900">Broadcast Audio Anchor</span>
                <p className="text-[11px] text-slate-500">
                  {isPlayingAudio ? 'Broadcasting verified news report...' : 'Listen to professional voice anchor reading full story'}
                </p>
              </div>
            </div>

            <button
              onClick={handleToggleSpeech}
              className={`px-4 py-1.5 rounded-lg text-xs font-bold transition flex items-center space-x-1.5 ${
                isPlayingAudio
                  ? 'bg-red-600 text-white'
                  : 'bg-slate-900 hover:bg-slate-800 text-white'
              }`}
            >
              {isPlayingAudio ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              <span>{isPlayingAudio ? 'Stop Listening' : 'Listen Report'}</span>
            </button>
          </div>

          {/* Editorial Tabs */}
          <div className="flex items-center space-x-2 border-b border-slate-200 text-xs font-bold overflow-x-auto pb-0.5">
            <button
              onClick={() => setActiveTab('story')}
              className={`px-3 py-2 border-b-2 transition flex items-center space-x-1.5 ${
                activeTab === 'story'
                  ? 'border-[#bb1919] text-[#bb1919]'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Full In-Depth Story ({paragraphsToRender.length} Paragraphs)</span>
            </button>

            <button
              onClick={() => setActiveTab('facts')}
              className={`px-3 py-2 border-b-2 transition flex items-center space-x-1.5 ${
                activeTab === 'facts'
                  ? 'border-[#bb1919] text-[#bb1919]'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              <span>Verified Facts</span>
            </button>

            <button
              onClick={() => setActiveTab('perspectives')}
              className={`px-3 py-2 border-b-2 transition flex items-center space-x-1.5 ${
                activeTab === 'perspectives'
                  ? 'border-[#bb1919] text-[#bb1919]'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              <Layers className="w-3.5 h-3.5 text-blue-600" />
              <span>5-Bureau Comparison</span>
            </button>

            <button
              onClick={() => setActiveTab('timeline')}
              className={`px-3 py-2 border-b-2 transition flex items-center space-x-1.5 ${
                activeTab === 'timeline'
                  ? 'border-[#bb1919] text-[#bb1919]'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              <Clock className="w-3.5 h-3.5 text-amber-600" />
              <span>Timeline & Quotes</span>
            </button>

            <button
              onClick={() => setActiveTab('urdu')}
              className={`px-3 py-2 border-b-2 transition flex items-center space-x-1.5 font-urdu ${
                activeTab === 'urdu'
                  ? 'border-emerald-600 text-emerald-700'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              <Languages className="w-3.5 h-3.5" />
              <span>مکمل اردو رپورٹ</span>
            </button>
          </div>

          {/* Loading */}
          {loading && (
            <div className="py-16 text-center space-y-3">
              <div className="w-8 h-8 rounded-full border-2 border-slate-300 border-t-[#bb1919] animate-spin mx-auto"></div>
              <p className="text-xs font-semibold text-slate-600">
                Compiling multi-bureau verified dossier across Geo News, BBC, CNN, Fox & CCTV...
              </p>
            </div>
          )}

          {/* Tab Content */}
          {!loading && (
            <div className="space-y-6">
              
              {/* TAB 1: FULL IN-DEPTH STORY (Multi-paragraph comprehensive narrative) */}
              {activeTab === 'story' && (
                <div className="space-y-6">
                  {/* Lead Summary Callout */}
                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
                      Editorial Executive Brief
                    </span>
                    <p className="text-sm sm:text-base font-semibold text-slate-900 leading-relaxed">
                      {detail?.executiveSummary || item.summary}
                    </p>
                  </div>

                  {/* Multi-Paragraph In-Depth Story Text (As explicitly requested by user) */}
                  <div className="space-y-4 text-slate-800 text-sm sm:text-base leading-relaxed font-normal">
                    <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 border-b border-slate-100 pb-1">
                      Complete In-Depth Investigation
                    </h3>
                    {paragraphsToRender.map((para, idx) => (
                      <p key={idx} className="leading-relaxed">
                        {para}
                      </p>
                    ))}
                  </div>

                  {/* Geopolitical & Market Reaction */}
                  {detail && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-3 border-t border-slate-100">
                      <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
                        <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center">
                          <TrendingUp className="w-3.5 h-3.5 mr-1.5 text-blue-600" /> Geopolitical Ramifications
                        </h4>
                        <p className="text-xs text-slate-700 leading-relaxed">
                          {detail.geopoliticalImpact}
                        </p>
                      </div>

                      <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
                        <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center">
                          <TrendingUp className="w-3.5 h-3.5 mr-1.5 text-emerald-600" /> Market & Economic Reaction
                        </h4>
                        <p className="text-xs text-slate-700 leading-relaxed">
                          {detail.marketReaction}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* TAB 2: VERIFIED FACTS */}
              {activeTab === 'facts' && detail && (
                <div className="space-y-4">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    Fact-Checked Intelligence Points ({detail.keyFacts.length})
                  </h3>
                  <div className="space-y-2.5">
                    {detail.keyFacts.map((fact, idx) => (
                      <div
                        key={idx}
                        className="p-3.5 rounded-xl bg-white border border-slate-200 flex items-start space-x-3 shadow-xs"
                      >
                        <span className="flex-shrink-0 w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-xs mt-0.5">
                          {idx + 1}
                        </span>
                        <p className="text-xs sm:text-sm text-slate-800 leading-relaxed">
                          {fact}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 3: 5-BUREAU PERSPECTIVES */}
              {activeTab === 'perspectives' && detail && (
                <div className="space-y-3.5">
                  <p className="text-xs text-slate-500">
                    How different international news desks cover and contextualize this specific event:
                  </p>

                  <div className="space-y-3">
                    <div className="p-3.5 rounded-xl bg-emerald-50/70 border border-emerald-200 space-y-1">
                      <span className="text-xs font-bold text-emerald-800">🇵🇰 Geo News (South Asia Focus)</span>
                      <p className="text-xs text-slate-800 leading-relaxed">{detail.networkPerspectives.geoPerspective}</p>
                    </div>

                    <div className="p-3.5 rounded-xl bg-red-50/70 border border-red-200 space-y-1">
                      <span className="text-xs font-bold text-red-800">🇬🇧 BBC World (UK / Europe)</span>
                      <p className="text-xs text-slate-800 leading-relaxed">{detail.networkPerspectives.bbcPerspective}</p>
                    </div>

                    <div className="p-3.5 rounded-xl bg-rose-50/70 border border-rose-200 space-y-1">
                      <span className="text-xs font-bold text-rose-800">🇺🇸 CNN International (US / Transatlantic)</span>
                      <p className="text-xs text-slate-800 leading-relaxed">{detail.networkPerspectives.cnnPerspective}</p>
                    </div>

                    <div className="p-3.5 rounded-xl bg-blue-50/70 border border-blue-200 space-y-1">
                      <span className="text-xs font-bold text-blue-800">🇺🇸 Fox News (Policy & National Defense)</span>
                      <p className="text-xs text-slate-800 leading-relaxed">{detail.networkPerspectives.foxPerspective}</p>
                    </div>

                    <div className="p-3.5 rounded-xl bg-amber-50/70 border border-amber-200 space-y-1">
                      <span className="text-xs font-bold text-amber-800">🇨🇳 CCTV / CGTN (Asia-Pacific & BRICS)</span>
                      <p className="text-xs text-slate-800 leading-relaxed">{detail.networkPerspectives.cctvPerspective}</p>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 4: TIMELINE & QUOTES */}
              {activeTab === 'timeline' && detail && (
                <div className="space-y-6">
                  <div className="space-y-3">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                      Chronological Progression
                    </h3>
                    <div className="space-y-3 pl-3 border-l-2 border-slate-300">
                      {detail.timeline.map((timelineItem, idx) => (
                        <div key={idx} className="relative pl-3 space-y-1">
                          <div className="absolute -left-[18px] top-1.5 w-2 h-2 rounded-full bg-slate-900"></div>
                          <span className="text-[11px] font-bold text-slate-600">{timelineItem.time}</span>
                          <p className="text-xs text-slate-800">{timelineItem.event}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {detail.quotes && detail.quotes.length > 0 && (
                    <div className="space-y-3 pt-2">
                      <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                        Official Spokesperson Statements
                      </h3>
                      <div className="grid grid-cols-1 gap-3">
                        {detail.quotes.map((q, idx) => (
                          <div key={idx} className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                            <Quote className="w-4 h-4 text-slate-400" />
                            <p className="text-xs sm:text-sm text-slate-800 italic leading-relaxed">
                              "{q.statement}"
                            </p>
                            <div className="text-[11px] text-slate-600 font-semibold border-t border-slate-200 pt-1">
                              {q.speaker} — <span className="font-normal text-slate-500">{q.title}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* TAB 5: URDU FULL REPORT */}
              {activeTab === 'urdu' && (
                <div className="space-y-4 text-right dir-rtl">
                  <div className="p-6 rounded-xl bg-emerald-50/50 border border-emerald-200 space-y-4">
                    <h3 className="text-base font-bold text-emerald-900 font-urdu border-b border-emerald-200/80 pb-2">
                      مفصل اردو نیوز رپورٹ (جیو نیوز و بین الاقوامی ذرائع)
                    </h3>
                    <p className="text-base sm:text-lg text-slate-900 font-urdu leading-loose">
                      {detail?.urduSummary || item.summaryUrdu}
                    </p>
                    {detail?.urduFullText && detail.urduFullText.map((p, i) => (
                      <p key={i} className="text-base text-slate-800 font-urdu leading-loose">
                        {p}
                      </p>
                    ))}
                  </div>
                </div>
              )}

            </div>
          )}

        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <div className="flex items-center space-x-2 text-xs text-slate-500">
            <span>Source: <strong>{item.source}</strong></span>
            <span>·</span>
            <span>{item.location}</span>
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2 rounded-lg text-xs font-bold bg-slate-900 hover:bg-slate-800 text-white transition"
          >
            Close Report
          </button>
        </div>

      </div>
    </div>
  );
};
