import React, { useState, useEffect } from 'react';
import {
  X,
  Sparkles,
  FileText,
  Clock,
  CheckCircle2,
  Share2,
  Languages,
  ArrowRight,
  ShieldCheck,
  Bookmark
} from 'lucide-react';
import { NewsItem, AISummaryResponse } from '../types';
import { NETWORKS } from '../utils/constants';

interface AISummaryModalProps {
  item: NewsItem | null;
  onClose: () => void;
  onOpenFullDetail: (item: NewsItem) => void;
  onToggleBookmark: (id: string) => void;
  isBookmarked: boolean;
  preferUrdu: boolean;
}

export const AISummaryModal: React.FC<AISummaryModalProps> = ({
  item,
  onClose,
  onOpenFullDetail,
  onToggleBookmark,
  isBookmarked,
  preferUrdu,
}) => {
  const [loading, setLoading] = useState<boolean>(true);
  const [summaryData, setSummaryData] = useState<AISummaryResponse | null>(null);
  const [activeLang, setActiveLang] = useState<'en' | 'ur'>(preferUrdu ? 'ur' : 'en');
  const [copied, setCopied] = useState<boolean>(false);

  useEffect(() => {
    if (!item) return;

    let isMounted = true;
    setLoading(true);
    setSummaryData(null);
    setActiveLang(preferUrdu ? 'ur' : 'en');

    // Fetch AI Summary from backend
    fetch('/api/news/summary', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        headline: item.title,
        source: item.source,
        category: item.category,
        text: item.summary,
      }),
    })
      .then((res) => res.json())
      .then((data) => {
        if (isMounted) {
          if (data.summary) {
            setSummaryData(data.summary);
          }
          setLoading(false);
        }
      })
      .catch((err) => {
        console.error('Failed to load AI summary:', err);
        if (isMounted) setLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [item, preferUrdu]);

  if (!item) return null;

  const network = NETWORKS[item.sourceCode] || NETWORKS.bbc;

  const handleCopySummary = () => {
    if (!summaryData) return;
    const text = `AI NEWS SUMMARY: ${item.title}\nSource: ${item.source}\n\nKEY TAKEAWAY:\n${summaryData.keyTakeaway}\n\nFACTS:\n${summaryData.bulletPoints.map((b, i) => `• ${b}`).join('\n')}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative w-full max-w-2xl bg-white border border-slate-300 rounded-2xl shadow-2xl overflow-hidden text-slate-900 flex flex-col max-h-[90vh]">
        
        {/* Header Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-[#f8fafc]">
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-600 animate-pulse"></span>
            <div className="flex items-center space-x-2">
              <span className="font-bold text-xs uppercase tracking-wider text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                AI Executive Summary (خلاصہ)
              </span>
              <span className="text-xs font-semibold text-slate-500">
                {network.flag} {item.source}
              </span>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {/* Language Switcher */}
            <div className="flex items-center bg-slate-200 p-0.5 rounded-lg text-xs font-bold">
              <button
                onClick={() => setActiveLang('en')}
                className={`px-2 py-1 rounded transition ${activeLang === 'en' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'}`}
              >
                English
              </button>
              <button
                onClick={() => setActiveLang('ur')}
                className={`px-2 py-1 rounded transition font-urdu ${activeLang === 'ur' ? 'bg-white text-emerald-700 shadow-sm' : 'text-slate-600'}`}
              >
                اردو
              </button>
            </div>

            <button
              onClick={handleCopySummary}
              className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition"
              title="Copy Summary"
            >
              <Share2 className="w-4 h-4" />
            </button>

            <button
              onClick={() => onToggleBookmark(item.id)}
              className={`p-1.5 rounded-lg transition ${isBookmarked ? 'text-red-600 bg-red-50' : 'text-slate-500 hover:text-slate-800 hover:bg-slate-100'}`}
              title="Bookmark"
            >
              <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`} />
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8 space-y-6 overflow-y-auto flex-1">
          
          {/* Headline */}
          <div className="space-y-2">
            <div className="flex items-center space-x-2 text-xs text-slate-500 font-medium">
              <span>{item.category}</span>
              <span>·</span>
              <span>{item.location}</span>
              <span>·</span>
              <span>{item.displayTime}</span>
              <span>·</span>
              <span className="text-emerald-700 font-semibold flex items-center">
                <ShieldCheck className="w-3.5 h-3.5 mr-1" />
                Verified ({item.verification.confirmedBy.join(', ')})
              </span>
            </div>

            <h2 className="text-xl sm:text-2xl font-bold font-headline text-slate-900 leading-snug">
              {activeLang === 'ur' && item.titleUrdu ? item.titleUrdu : item.title}
            </h2>
          </div>

          {/* Loading State */}
          {loading && (
            <div className="py-12 flex flex-col items-center justify-center space-y-3">
              <div className="w-8 h-8 rounded-full border-2 border-slate-300 border-t-amber-600 animate-spin"></div>
              <p className="text-xs font-semibold text-slate-600">
                Generating concise AI fact summary across multi-bureau dispatches...
              </p>
            </div>
          )}

          {/* Render Summary Content */}
          {!loading && summaryData && (
            <div className="space-y-5">
              
              {/* Key Takeaway Callout */}
              <div className="p-4 rounded-xl bg-amber-50/80 border border-amber-200/90 space-y-1.5">
                <span className="text-[11px] font-bold uppercase tracking-wider text-amber-800 flex items-center">
                  <Sparkles className="w-3.5 h-3.5 mr-1 text-amber-600" /> Bottom-Line Key Takeaway
                </span>
                <p className={`text-sm sm:text-base font-semibold text-slate-900 leading-relaxed ${activeLang === 'ur' ? 'font-urdu dir-rtl text-right' : ''}`}>
                  {activeLang === 'ur' ? summaryData.urduKeyTakeaway : summaryData.keyTakeaway}
                </p>
              </div>

              {/* Bullet Points */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Key Verified Facts
                </h4>
                <div className={`space-y-2.5 ${activeLang === 'ur' ? 'dir-rtl text-right' : ''}`}>
                  {(activeLang === 'ur' ? summaryData.urduBulletPoints : summaryData.bulletPoints).map((point, idx) => (
                    <div key={idx} className="flex items-start space-x-2.5">
                      <span className="flex-shrink-0 w-5 h-5 rounded-full bg-slate-100 text-slate-700 flex items-center justify-center font-bold text-xs mt-0.5 border border-slate-300">
                        {idx + 1}
                      </span>
                      <p className={`text-sm text-slate-800 leading-relaxed ${activeLang === 'ur' ? 'font-urdu text-base' : ''}`}>
                        {point}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Multi-Bureau Verification Notice */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600 flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                  <span>Cross-checked against <strong>{item.verification.confirmedBy.length} global networks</strong> ({item.verification.confirmedBy.join(', ')}).</span>
                </div>
                <span className="text-slate-400 text-[11px] font-mono">{summaryData.readTime}</span>
              </div>

            </div>
          )}

        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-200 transition"
          >
            Close
          </button>

          <button
            onClick={() => {
              onClose();
              onOpenFullDetail(item);
            }}
            className="px-5 py-2 rounded-lg text-xs font-bold bg-[#bb1919] hover:bg-[#a01515] text-white transition flex items-center space-x-2 shadow-sm"
          >
            <span>Read Full Story</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </div>
  );
};
