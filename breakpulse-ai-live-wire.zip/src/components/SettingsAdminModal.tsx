import React, { useState, useEffect } from 'react';
import {
  X,
  Settings,
  Shield,
  KeyRound,
  Pin,
  Tv,
  PlusCircle,
  Trash2,
  CheckCircle2,
  Volume2,
  VolumeX,
  Sparkles,
  Layers,
  Clock,
  Radio,
  Eye,
  AlertTriangle,
  Lock,
  LogOut,
  FileText,
  Send,
  Image as ImageIcon
} from 'lucide-react';
import { NewsItem, AdminSettingsState } from '../types';
import { formatYouTubeEmbedUrl, OFFICIAL_STREAM_PRESETS } from '../utils/youtubeHelper';

interface SettingsAdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  // Settings props
  pulseIntervalSec: number;
  onChangeInterval: (sec: number) => void;
  isMuted: boolean;
  onToggleMute: () => void;
  preferUrdu: boolean;
  onToggleLanguage: () => void;
  onClearHistory: () => void;
  // Admin CMS props
  adminSettings: AdminSettingsState;
  onUpdateAdminSettings: (settings: AdminSettingsState) => void;
  onPublishCustomStory: (story: NewsItem) => void;
  onDeleteCustomStory: (id: string) => void;
  onTogglePinStory: (id: string) => void;
  customStories: NewsItem[];
}

export const SettingsAdminModal: React.FC<SettingsAdminModalProps> = ({
  isOpen,
  onClose,
  pulseIntervalSec,
  onChangeInterval,
  isMuted,
  onToggleMute,
  preferUrdu,
  onToggleLanguage,
  onClearHistory,
  adminSettings,
  onUpdateAdminSettings,
  onPublishCustomStory,
  onDeleteCustomStory,
  onTogglePinStory,
  customStories,
}) => {
  const [activeTab, setActiveTab] = useState<'settings' | 'breakpulse-admin'>('settings');
  // Security requirement: Must be locked by default whenever opened!
  const [isUnlocked, setIsUnlocked] = useState<boolean>(false);
  const [enteredPasscode, setEnteredPasscode] = useState<string>('');
  const [passcodeError, setPasscodeError] = useState<string>('');

  // Post mode: Quick Headline or Full Article
  const [postMode, setPostMode] = useState<'quick-headline' | 'full-article'>('quick-headline');

  // Password change state
  const [newPasscode, setNewPasscode] = useState<string>('');
  const [passChangeSuccess, setPassChangeSuccess] = useState<boolean>(false);

  // Quick Headline Form
  const [quickTitle, setQuickTitle] = useState<string>('');
  const [quickTitleUrdu, setQuickTitleUrdu] = useState<string>('');
  const [quickCategory, setQuickCategory] = useState<NewsItem['category']>('Country Condition');
  const [quickSource, setQuickSource] = useState<NewsItem['source']>('Geo News');
  const [quickPin, setQuickPin] = useState<boolean>(false); // Separate pin option as requested!

  // Full Article Form
  const [fullTitle, setFullTitle] = useState<string>('');
  const [fullTitleUrdu, setFullTitleUrdu] = useState<string>('');
  const [fullCategory, setFullCategory] = useState<NewsItem['category']>('Country Condition');
  const [fullSummary, setFullSummary] = useState<string>('');
  const [fullParagraphs, setFullParagraphs] = useState<string>('');
  const [fullImageUrl, setFullImageUrl] = useState<string>(
    'https://images.unsplash.com/photo-1541872703-74c5e44368f9?auto=format&fit=crop&w=1200&q=80'
  );
  const [fullPin, setFullPin] = useState<boolean>(false);
  const [publishSuccess, setPublishSuccess] = useState<boolean>(false);
  const [deletingStoryId, setDeletingStoryId] = useState<string | null>(null);

  // Live Stream Settings
  const [streamUrl, setStreamUrl] = useState<string>(adminSettings.liveStreamUrl || '');
  const [streamActive, setStreamActive] = useState<boolean>(adminSettings.isStreamActive || false);
  const [tickerAlertText, setTickerAlertText] = useState<string>(adminSettings.tickerAlert || '');
  const [streamSaveSuccess, setStreamSaveSuccess] = useState<boolean>(false);

  // Reset unlock state whenever modal closes to enforce security
  useEffect(() => {
    if (!isOpen) {
      setIsUnlocked(false);
      setEnteredPasscode('');
      setPasscodeError('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleUnlockAdmin = (e: React.FormEvent) => {
    e.preventDefault();
    if (enteredPasscode.trim() === adminSettings.adminPasscode) {
      setIsUnlocked(true);
      setPasscodeError('');
    } else {
      setPasscodeError('غلط پاس ورڈ! برائے مہربانی درست ایڈمن پاس ورڈ درج کریں۔ (Default: admin123)');
    }
  };

  const handleLockAdmin = () => {
    setIsUnlocked(false);
    setEnteredPasscode('');
    setActiveTab('settings');
  };

  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPasscode.trim().length >= 4) {
      onUpdateAdminSettings({
        ...adminSettings,
        adminPasscode: newPasscode.trim(),
      });
      setPassChangeSuccess(true);
      setNewPasscode('');
      setTimeout(() => setPassChangeSuccess(false), 3000);
    }
  };

  const handleSaveStreamSettings = (presetUrl?: string) => {
    const rawUrl = presetUrl || streamUrl;
    const formatted = formatYouTubeEmbedUrl(rawUrl.trim());
    setStreamUrl(formatted);
    onUpdateAdminSettings({
      ...adminSettings,
      liveStreamUrl: formatted,
      isStreamActive: streamActive,
      tickerAlert: tickerAlertText.trim(),
    });
    setStreamSaveSuccess(true);
    setTimeout(() => setStreamSaveSuccess(false), 3000);
  };

  // Submit Quick Headline Drop
  const handlePublishQuickHeadline = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickTitle.trim()) return;

    const sourceMap: Record<string, NewsItem['sourceCode']> = {
      'Geo News': 'geo',
      'BBC World': 'bbc',
      'CNN': 'cnn',
      'Fox News': 'fox',
      'CCTV': 'cctv',
    };

    const newStory: NewsItem = {
      id: `breakpulse-custom-${Date.now()}`,
      title: quickTitle.trim(),
      titleUrdu: quickTitleUrdu.trim() || quickTitle.trim(),
      source: quickSource,
      sourceCode: sourceMap[quickSource] || 'geo',
      category: quickCategory,
      urgency: 'BREAKING',
      timestamp: new Date().toISOString(),
      displayTime: 'Just now',
      summary: quickTitle.trim(),
      summaryUrdu: quickTitleUrdu.trim() || quickTitle.trim(),
      location: 'BreakPulse Wire Desk',
      tags: ['Live Wire', quickCategory],
      read: false,
      imageUrl: 'https://images.unsplash.com/photo-1504711434969-e33886168f5c?auto=format&fit=crop&w=1200&q=80',
      isPinned: quickPin, // Separate pin state!
      isCustomAdmin: true,
      fullStoryParagraphs: [
        quickTitle.trim(),
        'This breaking update was broadcast through the BreakPulse editorial wire desk.',
        'Developing story monitored in real-time across international news bureaus.',
      ],
      verification: {
        status: 'VERIFIED',
        confidenceScore: 100,
        confirmedBy: [quickSource, 'BBC World'],
        primaryOutlet: 'BreakPulse Verified Newsroom',
        notes: 'Dispatched through BreakPulse Admin Wire.',
      },
      bulletSummary: [
        quickTitle.trim(),
        'Priority news bulletin confirmed by news desk.',
      ],
      keyTakeaway: 'Verified breaking update added to live wire.',
    };

    onPublishCustomStory(newStory);
    setPublishSuccess(true);
    setQuickTitle('');
    setQuickTitleUrdu('');
    setTimeout(() => setPublishSuccess(false), 2500);
  };

  // Submit Full Article
  const handlePublishFullArticle = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullTitle.trim() || !fullSummary.trim()) return;

    const paragraphs = fullParagraphs.trim()
      ? fullParagraphs.split('\n\n').filter((p) => p.trim())
      : [fullSummary];

    const newStory: NewsItem = {
      id: `breakpulse-custom-${Date.now()}`,
      title: fullTitle.trim(),
      titleUrdu: fullTitleUrdu.trim() || fullTitle.trim(),
      source: 'Geo News',
      sourceCode: 'geo',
      category: fullCategory,
      urgency: 'BREAKING',
      timestamp: new Date().toISOString(),
      displayTime: 'Just now',
      summary: fullSummary.trim(),
      summaryUrdu: fullTitleUrdu.trim() || fullSummary.trim(),
      location: 'BreakPulse National Desk',
      tags: ['BreakPulse', 'Editorial', fullCategory],
      read: false,
      imageUrl: fullImageUrl,
      isPinned: fullPin,
      isCustomAdmin: true,
      fullStoryParagraphs: paragraphs,
      verification: {
        status: 'VERIFIED',
        confidenceScore: 100,
        confirmedBy: ['Geo News', 'BBC World'],
        primaryOutlet: 'BreakPulse Editorial Bureau',
        notes: 'Directly verified and authored by BreakPulse Editorial Board.',
      },
      bulletSummary: [
        fullSummary.trim(),
        'Detailed multi-paragraph report verified by editorial board.',
      ],
      keyTakeaway: 'Comprehensive dispatch published to live edition.',
    };

    onPublishCustomStory(newStory);
    setPublishSuccess(true);
    setFullTitle('');
    setFullTitleUrdu('');
    setFullSummary('');
    setFullParagraphs('');
    setTimeout(() => setPublishSuccess(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/75 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative w-full max-w-3xl max-h-[92vh] bg-white border border-slate-300 rounded-2xl shadow-2xl overflow-hidden text-slate-900 flex flex-col">
        
        {/* Header Tabs */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-[#f8fafc]">
          <div className="flex items-center space-x-2">
            <Settings className="w-5 h-5 text-slate-700" />
            <div className="flex items-center space-x-1 bg-slate-200 p-0.5 rounded-lg text-xs font-bold">
              <button
                onClick={() => setActiveTab('settings')}
                className={`px-3 py-1.5 rounded transition ${
                  activeTab === 'settings' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
                }`}
              >
                Portal Settings (سیٹنگز)
              </button>
              <button
                onClick={() => setActiveTab('breakpulse-admin')}
                className={`px-3 py-1.5 rounded transition flex items-center space-x-1.5 ${
                  activeTab === 'breakpulse-admin' ? 'bg-[#bb1919] text-white shadow-sm' : 'text-slate-600'
                }`}
              >
                <Shield className="w-3.5 h-3.5" />
                <span>BreakPulse Admin (ایڈمن پینل)</span>
                {isUnlocked && <span className="w-2 h-2 rounded-full bg-emerald-400"></span>}
              </button>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {/* Explicit Lock / Logout Button requested by user */}
            {isUnlocked && (
              <button
                onClick={handleLockAdmin}
                className="px-2.5 py-1 rounded bg-slate-200 hover:bg-red-100 hover:text-red-700 text-slate-700 text-xs font-bold transition flex items-center space-x-1"
                title="Lock Admin Panel & Log Out"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Lock Admin (بند کریں)</span>
              </button>
            )}

            <button
              onClick={() => {
                handleLockAdmin();
                onClose();
              }}
              className="p-1.5 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8 space-y-6 overflow-y-auto flex-1">
          
          {/* TAB 1: GENERAL USER SETTINGS */}
          {activeTab === 'settings' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-base font-bold text-slate-900">Portal Broadcast Preferences</h3>
                <p className="text-xs text-slate-500">Configure pulse speed, acoustic chime sound, and language options.</p>
              </div>

              {/* 1. Pulse Speed */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div>
                  <h4 className="text-xs font-bold text-slate-900 uppercase">Ticker Rotation Speed</h4>
                  <p className="text-xs text-slate-500">How frequently the breaking ticker advances.</p>
                </div>
                <div className="flex items-center space-x-1 bg-white p-1 rounded-lg border border-slate-200 text-xs font-bold">
                  {[3, 5, 10, 15].map((sec) => (
                    <button
                      key={sec}
                      onClick={() => onChangeInterval(sec)}
                      className={`px-2.5 py-1 rounded transition ${
                        pulseIntervalSec === sec ? 'bg-[#bb1919] text-white' : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      {sec}s
                    </button>
                  ))}
                </div>
              </div>

              {/* 2. Sweet Ticking Audio */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-slate-900 uppercase">Sweet Ticker Acoustic Chime</h4>
                  <p className="text-xs text-slate-500">Gentle, low-amplitude acoustic blip when fresh headline loads.</p>
                </div>
                <button
                  onClick={onToggleMute}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center space-x-1.5 border ${
                    !isMuted ? 'bg-emerald-600 text-white border-emerald-600' : 'bg-white text-slate-700 border-slate-300'
                  }`}
                >
                  {!isMuted ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                  <span>{!isMuted ? 'Chime Active' : 'Muted'}</span>
                </button>
              </div>

              {/* 3. Language */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-slate-900 uppercase">Headline Translation Language</h4>
                  <p className="text-xs text-slate-500">Toggle English headlines or native Urdu translation.</p>
                </div>
                <button
                  onClick={onToggleLanguage}
                  className="px-3 py-1.5 rounded-lg text-xs font-bold bg-white border border-slate-300 hover:bg-slate-100 text-slate-800 transition"
                >
                  {preferUrdu ? 'Urdu Active (اردو)' : 'English Active (انگریزی)'}
                </button>
              </div>

              {/* 4. Reset & Clear History */}
              <div className="p-4 rounded-xl bg-red-50/50 border border-red-200 flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-red-900 uppercase">Reset Headline Archive</h4>
                  <p className="text-xs text-red-700">Clear read statuses and reset today's headlines to unread.</p>
                </div>
                <button
                  onClick={onClearHistory}
                  className="px-3 py-1.5 rounded-lg text-xs font-bold bg-white hover:bg-red-50 text-red-700 border border-red-300 transition"
                >
                  Reset History
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: BREAKPULSE ADMIN CMS */}
          {activeTab === 'breakpulse-admin' && (
            <div className="space-y-6">
              
              {/* If Locked, Show Password Form (Always requires password on open) */}
              {!isUnlocked ? (
                <div className="py-12 max-w-md mx-auto text-center space-y-4">
                  <div className="w-12 h-12 bg-red-100 text-[#bb1919] rounded-2xl flex items-center justify-center mx-auto">
                    <Lock className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-slate-900">BreakPulse Admin Portal (ایڈمن لاگ ان)</h3>
                    <p className="text-xs text-slate-500">
                      Enter your admin passcode to access live pinning, custom story dispatch, and stream controls. (Default passcode: <strong className="text-slate-800">admin123</strong>)
                    </p>
                  </div>

                  <form onSubmit={handleUnlockAdmin} className="space-y-3 pt-2">
                    <input
                      type="password"
                      autoFocus
                      value={enteredPasscode}
                      onChange={(e) => setEnteredPasscode(e.target.value)}
                      placeholder="Enter Admin Passcode..."
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:outline-none focus:border-[#bb1919]"
                    />
                    {passcodeError && (
                      <p className="text-xs font-semibold text-red-600 font-urdu">{passcodeError}</p>
                    )}
                    <button
                      type="submit"
                      className="w-full py-2.5 rounded-xl bg-[#bb1919] hover:bg-[#a01515] text-white text-xs font-bold transition shadow-sm"
                    >
                      Unlock Admin Panel
                    </button>
                  </form>
                </div>
              ) : (
                /* Unlocked Admin Panel */
                <div className="space-y-8 animate-in fade-in duration-200">
                  
                  {/* Status Bar, Logout Button, and Change Password */}
                  <div className="p-4 rounded-xl bg-slate-900 text-white flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
                    <div className="flex items-center space-x-2">
                      <Shield className="w-4 h-4 text-emerald-400" />
                      <span className="text-xs font-bold">Admin CMS Session Authenticated</span>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
                      <form onSubmit={handleChangePassword} className="flex items-center space-x-1.5 flex-1 sm:flex-initial">
                        <input
                          type="password"
                          value={newPasscode}
                          onChange={(e) => setNewPasscode(e.target.value)}
                          placeholder="Change Passcode..."
                          className="px-2.5 py-1 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-400 focus:outline-none w-36"
                        />
                        <button
                          type="submit"
                          className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition flex-shrink-0"
                        >
                          Save
                        </button>
                      </form>

                      {/* Prominent Lock/Close Button */}
                      <button
                        onClick={handleLockAdmin}
                        className="px-3 py-1 rounded-lg bg-red-600 hover:bg-red-500 text-white text-xs font-bold transition flex items-center space-x-1"
                        title="Lock Admin and require password next time"
                      >
                        <Lock className="w-3 h-3" />
                        <span>Lock & Close</span>
                      </button>
                    </div>
                  </div>
                  {passChangeSuccess && (
                    <p className="text-xs font-bold text-emerald-700 bg-emerald-50 p-2 rounded border border-emerald-200 text-center">
                      Admin passcode successfully changed and saved in browser storage!
                    </p>
                  )}

                  {/* 1. PUBLISH SECTION: MODE SELECTOR (Quick Headline vs Full Article) */}
                  <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-4">
                    <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                      <div>
                        <h4 className="text-sm font-bold text-slate-900 flex items-center">
                          <Send className="w-4 h-4 mr-1.5 text-[#bb1919]" />
                          Publish to Wire (خبر یا ہیڈ لائن چھوڑیں)
                        </h4>
                        <p className="text-xs text-slate-500">
                          Post a quick headline drop or a full in-depth journalistic article directly into the wire.
                        </p>
                      </div>

                      {/* Post Mode Toggle */}
                      <div className="flex items-center bg-slate-200 p-0.5 rounded-lg text-xs font-bold">
                        <button
                          type="button"
                          onClick={() => setPostMode('quick-headline')}
                          className={`px-2.5 py-1 rounded transition ${
                            postMode === 'quick-headline' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
                          }`}
                        >
                          Quick Headline
                        </button>
                        <button
                          type="button"
                          onClick={() => setPostMode('full-article')}
                          className={`px-2.5 py-1 rounded transition ${
                            postMode === 'full-article' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
                          }`}
                        >
                          Full Article
                        </button>
                      </div>
                    </div>

                    {/* MODE A: QUICK HEADLINE DROP */}
                    {postMode === 'quick-headline' && (
                      <form onSubmit={handlePublishQuickHeadline} className="space-y-3 text-xs">
                        <div>
                          <label className="block font-bold text-slate-700 mb-1">Headline (English)</label>
                          <input
                            type="text"
                            required
                            value={quickTitle}
                            onChange={(e) => setQuickTitle(e.target.value)}
                            placeholder="e.g. BreakPulse Flash: Supreme Court issues directive on national census..."
                            className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-none focus:border-slate-500"
                          />
                        </div>

                        <div>
                          <label className="block font-bold text-slate-700 mb-1">Headline (Urdu Translation)</label>
                          <input
                            type="text"
                            value={quickTitleUrdu}
                            onChange={(e) => setQuickTitleUrdu(e.target.value)}
                            placeholder="اردو سرخی یہاں لکھیں..."
                            className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-urdu dir-rtl text-right focus:outline-none focus:border-slate-500"
                          />
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div>
                            <label className="block font-bold text-slate-700 mb-1">Category</label>
                            <select
                              value={quickCategory}
                              onChange={(e) => setQuickCategory(e.target.value as any)}
                              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-none"
                            >
                              <option value="Country Condition">Country Condition (ملکی حالات)</option>
                              <option value="World Affairs">World Affairs (عالمی امور)</option>
                              <option value="Economy & Markets">Economy & Markets (معیشت)</option>
                              <option value="Sports">Sports (کھیل)</option>
                              <option value="Science & Tech">Science & Tech (سائنس و ٹیکنالوجی)</option>
                            </select>
                          </div>

                          <div>
                            <label className="block font-bold text-slate-700 mb-1">Channel Branding</label>
                            <select
                              value={quickSource}
                              onChange={(e) => setQuickSource(e.target.value as any)}
                              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-none"
                            >
                              <option value="Geo News">🇵🇰 Geo News</option>
                              <option value="BBC World">🇬🇧 BBC World</option>
                              <option value="CNN">🇺🇸 CNN</option>
                              <option value="Fox News">🇺🇸 Fox News</option>
                              <option value="CCTV">🇨🇳 CCTV</option>
                            </select>
                          </div>
                        </div>

                        {/* Separate Pin Toggle Button as requested */}
                        <div className="p-3 bg-white border border-slate-200 rounded-xl flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <Pin className={`w-4 h-4 ${quickPin ? 'text-red-600 fill-current' : 'text-slate-400'}`} />
                            <div>
                              <span className="font-bold text-slate-800">Pin to Top Story (سب سے اوپر پن کریں)</span>
                              <p className="text-[11px] text-slate-500">If checked, pins this headline as the main top story on the homepage.</p>
                            </div>
                          </div>
                          <input
                            type="checkbox"
                            checked={quickPin}
                            onChange={(e) => setQuickPin(e.target.checked)}
                            className="w-4 h-4 rounded text-red-600"
                          />
                        </div>

                        <button
                          type="submit"
                          className="w-full py-2.5 rounded-xl bg-[#bb1919] hover:bg-[#a01515] text-white font-bold text-xs transition shadow-sm flex items-center justify-center space-x-2"
                        >
                          <PlusCircle className="w-4 h-4" />
                          <span>{quickPin ? 'Publish & Pin Headline to Top' : 'Publish Headline to Live Wire'}</span>
                        </button>
                      </form>
                    )}

                    {/* MODE B: FULL ARTICLE CREATOR */}
                    {postMode === 'full-article' && (
                      <form onSubmit={handlePublishFullArticle} className="space-y-3.5 text-xs">
                        <div>
                          <label className="block font-bold text-slate-700 mb-1">Article Headline (English)</label>
                          <input
                            type="text"
                            required
                            value={fullTitle}
                            onChange={(e) => setFullTitle(e.target.value)}
                            placeholder="Enter full story headline..."
                            className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-none focus:border-slate-500"
                          />
                        </div>

                        <div>
                          <label className="block font-bold text-slate-700 mb-1">Article Headline (Urdu)</label>
                          <input
                            type="text"
                            value={fullTitleUrdu}
                            onChange={(e) => setFullTitleUrdu(e.target.value)}
                            placeholder="اردو سرخی..."
                            className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-urdu dir-rtl text-right focus:outline-none focus:border-slate-500"
                          />
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div>
                            <label className="block font-bold text-slate-700 mb-1">Category</label>
                            <select
                              value={fullCategory}
                              onChange={(e) => setFullCategory(e.target.value as any)}
                              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-none"
                            >
                              <option value="Country Condition">Country Condition (ملکی حالات)</option>
                              <option value="World Affairs">World Affairs (عالمی امور)</option>
                              <option value="Economy & Markets">Economy & Markets (معیشت)</option>
                              <option value="Sports">Sports (کھیل)</option>
                              <option value="Science & Tech">Science & Tech (سائنس و ٹیکنالوجی)</option>
                            </select>
                          </div>

                          <div>
                            <label className="block font-bold text-slate-700 mb-1">Editorial Image URL</label>
                            <input
                              type="text"
                              value={fullImageUrl}
                              onChange={(e) => setFullImageUrl(e.target.value)}
                              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-none focus:border-slate-500"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block font-bold text-slate-700 mb-1">Executive Summary (خلاصہ)</label>
                          <textarea
                            rows={2}
                            required
                            value={fullSummary}
                            onChange={(e) => setFullSummary(e.target.value)}
                            placeholder="Brief 2-sentence summary..."
                            className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-none focus:border-slate-500"
                          />
                        </div>

                        <div>
                          <label className="block font-bold text-slate-700 mb-1">
                            In-Depth Story Paragraphs (تفصیلی مضمون - پیراگراف خالی لائن سے الگ کریں)
                          </label>
                          <textarea
                            rows={4}
                            value={fullParagraphs}
                            onChange={(e) => setFullParagraphs(e.target.value)}
                            placeholder="Write comprehensive story narrative here..."
                            className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-none focus:border-slate-500"
                          />
                        </div>

                        {/* Separate Pin Toggle */}
                        <div className="p-3 bg-white border border-slate-200 rounded-xl flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <Pin className={`w-4 h-4 ${fullPin ? 'text-red-600 fill-current' : 'text-slate-400'}`} />
                            <span className="font-bold text-slate-800">Pin to Top Story (سب سے اوپر پن کریں)</span>
                          </div>
                          <input
                            type="checkbox"
                            checked={fullPin}
                            onChange={(e) => setFullPin(e.target.checked)}
                            className="w-4 h-4 rounded text-red-600"
                          />
                        </div>

                        <button
                          type="submit"
                          className="w-full py-2.5 rounded-xl bg-[#bb1919] hover:bg-[#a01515] text-white font-bold text-xs transition shadow-sm flex items-center justify-center space-x-2"
                        >
                          <PlusCircle className="w-4 h-4" />
                          <span>Publish Full Article</span>
                        </button>
                      </form>
                    )}

                    {publishSuccess && (
                      <p className="text-xs font-bold text-emerald-700 bg-emerald-50 p-2.5 rounded-xl border border-emerald-200 text-center">
                        Dispatched successfully! Story is live in the wire.
                      </p>
                    )}
                  </div>

                  {/* 2. ACTIVE ADMIN DISPATCHES MANAGEMENT (PIN / UNPIN / DELETE) */}
                  {customStories.length > 0 && (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <h4 className="text-xs font-bold text-slate-900 uppercase">
                          Active Admin Stories ({customStories.length})
                        </h4>
                        <span className="text-[11px] text-slate-500">Manage pins & permanent deletion</span>
                      </div>

                      <div className="space-y-2">
                        {customStories.map((story) => (
                          <div
                            key={story.id}
                            className="p-3.5 bg-white border border-slate-200 rounded-xl flex items-center justify-between gap-3 text-xs shadow-xs"
                          >
                            <div className="truncate flex-1">
                              <div className="flex items-center space-x-2">
                                {story.isPinned ? (
                                  <span className="px-1.5 py-0.2 rounded bg-red-100 text-red-800 font-bold text-[10px] flex items-center">
                                    <Pin className="w-2.5 h-2.5 mr-0.5 fill-current" /> PINNED
                                  </span>
                                ) : (
                                  <span className="px-1.5 py-0.2 rounded bg-slate-100 text-slate-700 font-bold text-[10px]">
                                    WIRE
                                  </span>
                                )}
                                <span className="font-bold text-slate-900 truncate">{story.title}</span>
                              </div>
                              <p className="text-[11px] text-slate-500 truncate">{story.summary}</p>
                            </div>

                            <div className="flex items-center space-x-2 flex-shrink-0">
                              {/* Toggle Pin/Unpin */}
                              <button
                                onClick={() => onTogglePinStory(story.id)}
                                className={`px-2.5 py-1 rounded text-[11px] font-bold transition flex items-center space-x-1 ${
                                  story.isPinned
                                    ? 'bg-amber-100 text-amber-900 hover:bg-amber-200'
                                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                                }`}
                                title={story.isPinned ? 'Unpin from top' : 'Pin to top'}
                              >
                                <Pin className="w-3 h-3" />
                                <span>{story.isPinned ? 'Unpin' : 'Pin'}</span>
                              </button>

                              {/* Permanent Delete Button with safe in-modal confirmation */}
                              {deletingStoryId === story.id ? (
                                <div className="flex items-center space-x-1 animate-in fade-in">
                                  <button
                                    onClick={() => {
                                      onDeleteCustomStory(story.id);
                                      setDeletingStoryId(null);
                                    }}
                                    className="px-2 py-0.5 rounded bg-red-600 hover:bg-red-700 text-white text-[10px] font-bold transition shadow-xs"
                                  >
                                    Confirm Delete
                                  </button>
                                  <button
                                    onClick={() => setDeletingStoryId(null)}
                                    className="px-1.5 py-0.5 rounded bg-slate-200 text-slate-700 text-[10px] font-medium hover:bg-slate-300 transition"
                                  >
                                    Cancel
                                  </button>
                                </div>
                              ) : (
                                <button
                                  onClick={() => setDeletingStoryId(story.id)}
                                  className="p-1.5 rounded text-slate-400 hover:text-red-600 hover:bg-red-50 transition"
                                  title="Delete headline permanently"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* 3. LIVE STREAM EMBED DESK WITH POPULAR PRESETS */}
                  <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3.5 text-xs">
                    <div className="flex items-center justify-between">
                      <h4 className="font-bold text-slate-900 flex items-center text-sm">
                        <Tv className="w-4 h-4 mr-1.5 text-blue-600" />
                        Live Stream Desk (لائیو نشریات)
                      </h4>
                      <div className="flex items-center space-x-1.5">
                        <input
                          type="checkbox"
                          id="streamActiveCheck"
                          checked={streamActive}
                          onChange={(e) => {
                            setStreamActive(e.target.checked);
                            onUpdateAdminSettings({
                              ...adminSettings,
                              isStreamActive: e.target.checked,
                            });
                          }}
                          className="w-4 h-4 rounded text-blue-600"
                        />
                        <label htmlFor="streamActiveCheck" className="font-bold text-slate-800">
                          Broadcast Live on Home
                        </label>
                      </div>
                    </div>

                    <p className="text-slate-500">
                      Select a 1-click official 24/7 news stream preset or enter a custom YouTube embed URL.
                    </p>

                    {/* Presets */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {OFFICIAL_STREAM_PRESETS.map((preset) => (
                        <button
                          key={preset.id}
                          type="button"
                          onClick={() => {
                            setStreamUrl(preset.url);
                            setStreamActive(true);
                            handleSaveStreamSettings(preset.url);
                          }}
                          className={`p-2 rounded-lg border font-bold text-[11px] transition text-center truncate ${
                            streamUrl.includes(preset.videoId)
                              ? 'bg-red-50 border-red-300 text-red-800'
                              : 'bg-white border-slate-200 hover:border-slate-400 text-slate-800'
                          }`}
                        >
                          {preset.name}
                        </button>
                      ))}
                    </div>

                    <div className="flex items-center space-x-2 pt-1">
                      <input
                        type="text"
                        value={streamUrl}
                        onChange={(e) => setStreamUrl(e.target.value)}
                        placeholder="Paste YouTube watch link, youtu.be, live link, or embed..."
                        className="flex-1 px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs focus:outline-none focus:border-slate-500"
                      />
                      <button
                        type="button"
                        onClick={() => handleSaveStreamSettings()}
                        className="px-4 py-2 bg-slate-900 text-white rounded-lg font-bold text-xs hover:bg-slate-800 transition flex-shrink-0"
                      >
                        Save Stream
                      </button>
                    </div>

                    {streamSaveSuccess && (
                      <p className="text-[11px] font-bold text-emerald-700 bg-emerald-50 p-2 rounded-lg border border-emerald-200 text-center animate-in fade-in">
                        Live Stream saved & broadcast activated across all devices!
                      </p>
                    )}
                  </div>

                  {/* 4. CUSTOM TOP TICKER ALERT */}
                  <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3 text-xs">
                    <h4 className="font-bold text-slate-900 flex items-center text-sm">
                      <Radio className="w-4 h-4 mr-1.5 text-amber-600" />
                      Top Ticker Custom Alert Banner
                    </h4>
                    <p className="text-slate-500">
                      Broadcast an urgent official notification across the red ticker. Leave blank to return to automated headline rotation.
                    </p>

                    <div className="flex items-center space-x-2">
                      <input
                        type="text"
                        value={tickerAlertText}
                        onChange={(e) => setTickerAlertText(e.target.value)}
                        placeholder="Leave blank for automatic live headline ticker..."
                        className="flex-1 px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs focus:outline-none focus:border-slate-500"
                      />
                      <button
                        type="button"
                        onClick={() => handleSaveStreamSettings()}
                        className="px-4 py-2 bg-slate-900 text-white rounded-lg font-bold text-xs hover:bg-slate-800 transition flex-shrink-0"
                      >
                        Save Alert
                      </button>
                    </div>
                  </div>

                </div>
              )}

            </div>
          )}

        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <span className="text-xs text-slate-400">
            BreakPulse Core Engine v3.8 • All custom dispatches saved in browser storage.
          </span>
          <button
            onClick={() => {
              handleLockAdmin();
              onClose();
            }}
            className="px-4 py-2 rounded-lg text-xs font-bold bg-slate-900 hover:bg-slate-800 text-white transition"
          >
            Close & Lock
          </button>
        </div>

      </div>
    </div>
  );
};
