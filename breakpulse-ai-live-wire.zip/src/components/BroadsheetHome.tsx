import React, { useState } from 'react';
import {
  Sparkles,
  Bookmark,
  ShieldCheck,
  Clock,
  ArrowRight,
  TrendingUp,
  MapPin,
  ExternalLink,
  Flame,
  Tv,
  Pin,
  ChevronDown,
  Layers
} from 'lucide-react';
import { NewsItem } from '../types';
import { NETWORKS } from '../utils/constants';
import { formatYouTubeEmbedUrl } from '../utils/youtubeHelper';

interface BroadsheetHomeProps {
  items: NewsItem[];
  onSelectStory: (item: NewsItem) => void;
  onOpenSummary: (item: NewsItem) => void;
  onToggleBookmark: (id: string) => void;
  bookmarkedIds: string[];
  preferUrdu: boolean;
  liveStreamUrl?: string;
  isStreamActive?: boolean;
  onNavigateToAllHeadlines?: () => void;
}

export const BroadsheetHome: React.FC<BroadsheetHomeProps> = ({
  items,
  onSelectStory,
  onOpenSummary,
  onToggleBookmark,
  bookmarkedIds,
  preferUrdu,
  liveStreamUrl,
  isStreamActive = false,
  onNavigateToAllHeadlines,
}) => {
  // Limit lower wire stories initially to prevent endless scrolling
  const [visibleCount, setVisibleCount] = useState<number>(6);

  if (items.length === 0) {
    return (
      <div className="py-24 text-center text-slate-500">
        <p className="font-semibold text-sm">No updates currently available in the wire.</p>
      </div>
    );
  }

  // Pinned stories appear first
  const sortedStories = [...items].sort((a, b) => {
    if (a.isPinned && !b.isPinned) return -1;
    if (!a.isPinned && b.isPinned) return 1;
    return 0;
  });

  const leadStory = sortedStories[0];
  const secondaryStories = sortedStories.slice(1, 4);
  const remainingStories = sortedStories.slice(4);
  const displayedWireStories = remainingStories.slice(0, visibleCount);
  const hasMoreWire = remainingStories.length > visibleCount;

  const leadNetwork = NETWORKS[leadStory.sourceCode] || NETWORKS.geo;
  const formattedStreamUrl = liveStreamUrl ? formatYouTubeEmbedUrl(liveStreamUrl) : '';

  return (
    <div className="space-y-8 sm:space-y-10">
      
      {/* 1. LIVE BROADCAST DESK (Configured via Admin CMS & fully functional) */}
      {isStreamActive && liveStreamUrl && (
        <div className="rounded-2xl overflow-hidden bg-slate-950 border border-slate-800 shadow-xl p-4 sm:p-5 space-y-3.5">
          <div className="flex flex-wrap items-center justify-between text-white text-xs gap-2">
            <div className="flex items-center space-x-2.5">
              <span className="w-2.5 h-2.5 rounded-full bg-red-600 animate-ping" />
              <span className="font-extrabold uppercase tracking-wider flex items-center text-red-400">
                <Tv className="w-4 h-4 mr-1.5 text-red-500" />
                Live Broadcast Desk (براہِ راست نشریات)
              </span>
            </div>
            
            <div className="flex items-center space-x-3 text-[11px]">
              <span className="text-slate-400 hidden sm:inline">Official Newsroom Stream</span>
              <a
                href={liveStreamUrl}
                target="_blank"
                rel="noreferrer"
                className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 transition flex items-center space-x-1"
                title="Open stream in separate window"
              >
                <span>Full Stream</span>
                <ExternalLink className="w-3 h-3 ml-0.5" />
              </a>
            </div>
          </div>

          <div className="aspect-video w-full rounded-xl overflow-hidden bg-black shadow-inner relative">
            <iframe
              src={formattedStreamUrl}
              title="BreakPulse Live Broadcast"
              className="w-full h-full border-0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowFullScreen
            />
          </div>
        </div>
      )}

      {/* 2. FRONT-PAGE LEAD HERO BROADCAST PACKAGE (BBC / Geo News standard) */}
      <section className="border-b border-slate-200 pb-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8">
          
          {/* Main Lead Story (8 cols) */}
          <div className="lg:col-span-8 space-y-4">
            <div
              className="relative aspect-video rounded-xl overflow-hidden bg-slate-100 border border-slate-200 group cursor-pointer shadow-xs"
              onClick={() => onSelectStory(leadStory)}
            >
              <img
                src={leadStory.imageUrl || 'https://images.unsplash.com/photo-1541872703-74c5e44368f9?auto=format&fit=crop&w=1200&q=80'}
                alt={leadStory.title}
                onError={(e) => {
                  (e.target as HTMLImageElement).src =
                    'https://images.unsplash.com/photo-1541872703-74c5e44368f9?auto=format&fit=crop&w=1200&q=80';
                }}
                className="w-full h-full object-cover group-hover:scale-102 transition duration-500"
              />
              <div className="absolute top-3 left-3 flex items-center space-x-2">
                {leadStory.isPinned ? (
                  <span className="px-2.5 py-1 rounded bg-[#bb1919] text-white text-[11px] font-extrabold uppercase tracking-wider shadow flex items-center">
                    <Pin className="w-3 h-3 mr-1 fill-current" /> Pinned Dispatch
                  </span>
                ) : (
                  <span className="px-2.5 py-1 rounded bg-[#bb1919] text-white text-[11px] font-extrabold uppercase tracking-wider shadow">
                    Top Story
                  </span>
                )}
                <span className="px-2.5 py-1 rounded bg-black/80 backdrop-blur-sm text-white text-[11px] font-bold shadow">
                  {leadNetwork.flag} {leadStory.source}
                </span>
              </div>
            </div>

            <div className="space-y-3">
              {/* Meta row */}
              <div className="flex flex-wrap items-center gap-2 sm:gap-3 text-xs text-slate-500 font-medium">
                <span className="text-slate-900 font-bold uppercase">{leadStory.category}</span>
                <span>·</span>
                <span>{leadStory.location}</span>
                <span>·</span>
                <span>{leadStory.displayTime}</span>
                <span>·</span>
                <span className="inline-flex items-center text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  <ShieldCheck className="w-3.5 h-3.5 mr-1" />
                  Verified ({leadStory.verification.confirmedBy.join(', ')})
                </span>
              </div>

              {/* Title */}
              <h2
                onClick={() => onSelectStory(leadStory)}
                className="text-2xl sm:text-3xl lg:text-4xl font-headline font-bold text-slate-900 hover:text-[#bb1919] transition cursor-pointer leading-tight"
              >
                {preferUrdu && leadStory.titleUrdu ? leadStory.titleUrdu : leadStory.title}
              </h2>

              {/* Summary Paragraph */}
              <p className="text-slate-700 text-sm sm:text-base leading-relaxed font-normal">
                {preferUrdu && leadStory.summaryUrdu ? leadStory.summaryUrdu : leadStory.summary}
              </p>

              {/* Action Buttons: Full Story & AI Summary */}
              <div className="flex flex-wrap items-center justify-between pt-2 gap-3">
                <div className="flex items-center space-x-3">
                  <button
                    onClick={() => onSelectStory(leadStory)}
                    className="px-4 py-2 rounded-lg bg-[#bb1919] hover:bg-[#a01515] text-white text-xs font-bold transition flex items-center space-x-1.5 shadow-sm"
                  >
                    <span>Read Full Story</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => onOpenSummary(leadStory)}
                    className="px-4 py-2 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 text-xs font-bold transition flex items-center space-x-1.5 shadow-sm"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                    <span>AI Summary (خلاصہ)</span>
                  </button>
                </div>

                <button
                  onClick={() => onToggleBookmark(leadStory.id)}
                  className={`p-2 rounded-lg border text-xs font-semibold transition ${
                    bookmarkedIds.includes(leadStory.id)
                      ? 'bg-red-50 text-red-600 border-red-200'
                      : 'bg-white text-slate-600 hover:text-slate-900 border-slate-200'
                  }`}
                  title="Bookmark story"
                >
                  <Bookmark className={`w-4 h-4 ${bookmarkedIds.includes(leadStory.id) ? 'fill-current' : ''}`} />
                </button>
              </div>
            </div>
          </div>

          {/* Developing Stories Column with Right-Side Thumbnails (4 cols) */}
          <div className="lg:col-span-4 flex flex-col justify-between space-y-4 border-t lg:border-t-0 lg:border-l lg:border-slate-200 lg:pl-6 pt-4 lg:pt-0">
            <div className="border-b border-slate-200 pb-2">
              <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-900 flex items-center">
                <Flame className="w-3.5 h-3.5 mr-1 text-[#bb1919]" /> Developing Stories (اہم خبریں)
              </h3>
            </div>

            <div className="space-y-4 flex-1 flex flex-col justify-between">
              {secondaryStories.map((item) => {
                const net = NETWORKS[item.sourceCode] || NETWORKS.geo;

                return (
                  <div
                    key={item.id}
                    className="p-3 rounded-xl bg-slate-50 hover:bg-white border border-slate-100 hover:border-slate-200 transition group flex items-start justify-between gap-3 shadow-xs"
                  >
                    <div className="flex-1 space-y-1.5 min-w-0">
                      <div className="flex items-center space-x-1.5 text-[11px] text-slate-500">
                        {item.isPinned && (
                          <span className="font-bold text-[9px] text-red-700 bg-red-100 px-1 py-0.2 rounded">PINNED</span>
                        )}
                        <span className="font-semibold text-slate-800">{net.flag} {item.source}</span>
                        <span>·</span>
                        <span>{item.displayTime}</span>
                      </div>

                      <h4
                        onClick={() => onSelectStory(item)}
                        className="font-headline font-bold text-xs sm:text-sm text-slate-900 group-hover:text-[#bb1919] transition cursor-pointer leading-snug line-clamp-2"
                      >
                        {preferUrdu && item.titleUrdu ? item.titleUrdu : item.title}
                      </h4>

                      <div className="flex items-center space-x-2 pt-0.5">
                        <button
                          onClick={() => onSelectStory(item)}
                          className="text-[11px] font-bold text-[#bb1919] hover:underline"
                        >
                          Full Details
                        </button>
                        <span className="text-slate-300">·</span>
                        <button
                          onClick={() => onOpenSummary(item)}
                          className="text-[11px] font-bold text-amber-700 hover:text-amber-800 flex items-center"
                        >
                          <Sparkles className="w-3 h-3 mr-0.5 text-amber-600" />
                          AI Summary
                        </button>
                      </div>
                    </div>

                    {/* Small crisp thumbnail photo on the right */}
                    <img
                      src={item.imageUrl || 'https://images.unsplash.com/photo-1504711434969-e33886168f5c?auto=format&fit=crop&w=400&q=80'}
                      alt={item.title}
                      onError={(e) => {
                        (e.target as HTMLImageElement).src =
                          'https://images.unsplash.com/photo-1541872703-74c5e44368f9?auto=format&fit=crop&w=400&q=80';
                      }}
                      className="w-18 h-18 sm:w-20 sm:h-20 rounded-lg object-cover flex-shrink-0 border border-slate-200 group-hover:scale-102 transition"
                    />
                  </div>
                );
              })}
            </div>
          </div>

        </div>
      </section>

      {/* 3. MULTI-BUREAU VERIFICATION NOTICE STRIP */}
      <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-slate-600">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold flex-shrink-0">
            <ShieldCheck className="w-4 h-4" />
          </div>
          <div>
            <p className="font-bold text-slate-900">
              BreakPulse Cross-Bureau Fact Verification Wire
            </p>
            <p className="text-slate-500 text-[11px]">
              Every news headline is authenticated across Geo News, BBC, CNN, Fox, and CCTV to verify official primary sources.
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2 flex-shrink-0">
          <span className="px-2.5 py-1 rounded bg-white border border-slate-200 text-slate-700 text-[11px] font-semibold shadow-xs">
            99.2% Verification Confidence
          </span>
        </div>
      </div>

      {/* 4. VERIFIED WIRE DISPATCHES WITH RIGHT-SIDE THUMBNAILS & LOAD MORE */}
      <section className="space-y-4">
        <div className="flex items-center justify-between border-b border-slate-200 pb-2">
          <h3 className="text-lg font-headline font-bold text-slate-900 flex items-center">
            <span className="w-1.5 h-4 bg-[#bb1919] mr-2" />
            Verified Wire Dispatches ({remainingStories.length} Stories Available)
          </h3>
          <span className="text-xs text-slate-500 font-medium hidden sm:inline">
            Showing latest dispatches
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {displayedWireStories.map((item) => {
            const net = NETWORKS[item.sourceCode] || NETWORKS.geo;
            const isBookmarked = bookmarkedIds.includes(item.id);

            return (
              <div
                key={item.id}
                className="group p-3.5 rounded-xl bg-white border border-slate-200 hover:border-slate-300 hover:shadow-md transition flex items-start justify-between gap-3.5"
              >
                <div className="flex-1 space-y-2 min-w-0">
                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <div className="flex items-center space-x-1.5 truncate">
                      {item.isPinned && (
                        <span className="font-bold text-[9px] text-red-700 bg-red-100 px-1 py-0.2 rounded">PINNED</span>
                      )}
                      <span className="font-semibold text-slate-800">{net.flag} {item.source}</span>
                      <span>·</span>
                      <span className="font-medium text-slate-600 truncate">{item.category}</span>
                    </div>

                    <button
                      onClick={() => onToggleBookmark(item.id)}
                      className={`p-1 text-slate-400 hover:text-slate-700 transition ${isBookmarked ? 'text-red-600' : ''}`}
                      title="Bookmark"
                    >
                      <Bookmark className={`w-3.5 h-3.5 ${isBookmarked ? 'fill-current' : ''}`} />
                    </button>
                  </div>

                  {/* Headline */}
                  <h4
                    onClick={() => onSelectStory(item)}
                    className="font-headline font-bold text-sm sm:text-base text-slate-900 group-hover:text-[#bb1919] transition cursor-pointer leading-snug line-clamp-2"
                  >
                    {preferUrdu && item.titleUrdu ? item.titleUrdu : item.title}
                  </h4>

                  {/* Summary */}
                  <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                    {item.summary}
                  </p>

                  {/* Action row */}
                  <div className="pt-1 flex items-center justify-between text-xs">
                    <span className="text-[11px] text-slate-400 flex items-center">
                      <Clock className="w-3 h-3 inline mr-1" />
                      {item.displayTime}
                    </span>

                    <div className="flex items-center space-x-1.5 sm:space-x-2">
                      <button
                        onClick={() => onOpenSummary(item)}
                        className="px-2 py-0.5 rounded bg-amber-50 hover:bg-amber-100 text-amber-800 font-bold text-[10px] sm:text-[11px] transition flex items-center space-x-1 border border-amber-200"
                      >
                        <Sparkles className="w-3 h-3 text-amber-600" />
                        <span>AI Summary</span>
                      </button>

                      <button
                        onClick={() => onSelectStory(item)}
                        className="px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-[10px] sm:text-[11px] transition"
                      >
                        Full Story
                      </button>
                    </div>
                  </div>
                </div>

                {/* Right-Side Thumbnail Photo */}
                <div
                  className="w-22 h-22 sm:w-28 sm:h-24 rounded-lg overflow-hidden bg-slate-100 border border-slate-200 flex-shrink-0 cursor-pointer"
                  onClick={() => onSelectStory(item)}
                >
                  <img
                    src={item.imageUrl || 'https://images.unsplash.com/photo-1504711434969-e33886168f5c?auto=format&fit=crop&w=400&q=80'}
                    alt={item.title}
                    onError={(e) => {
                      (e.target as HTMLImageElement).src =
                        'https://images.unsplash.com/photo-1541872703-74c5e44368f9?auto=format&fit=crop&w=400&q=80';
                    }}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                  />
                </div>
              </div>
            );
          })}
        </div>

        {/* Load More & Explore Archive Action Bar */}
        <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
          {hasMoreWire && (
            <button
              onClick={() => setVisibleCount((prev) => prev + 6)}
              className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition flex items-center justify-center space-x-1.5 shadow-sm"
            >
              <ChevronDown className="w-4 h-4" />
              <span>Load More Stories (مزید خبریں دیکھیں)</span>
            </button>
          )}

          {onNavigateToAllHeadlines && (
            <button
              onClick={onNavigateToAllHeadlines}
              className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs transition flex items-center justify-center space-x-1.5 border border-slate-300"
            >
              <Layers className="w-4 h-4 text-slate-600" />
              <span>View All in Headlines Archive (تمام سرخیاں)</span>
            </button>
          )}
        </div>
      </section>

    </div>
  );
};
